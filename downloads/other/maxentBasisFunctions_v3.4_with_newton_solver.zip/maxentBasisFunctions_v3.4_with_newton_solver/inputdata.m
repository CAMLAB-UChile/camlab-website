%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function to set data to start maxent computation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [dim,n,ncoord,x,prior_type,gamma,ilambda,rtol,compute,printmaxent,checktest,unstructured]...
         =inputdata()

% dimension of the domain of discretization
dim = 1;         % WARNING: ilambda in prior function data must be a vector of size dim

% number of nodes
n = 5;

% unstructured nodes
unstructured=1;  % 1 = true, 0 = false
                 % WARNING: if unstructured is TRUE, then gamma in prior function
                 % data must be a vector of size number of nodes whose
                 % entries are the gamma value for each node in the mesh

% nodal coordinates
ncoord = [0; 0.25; 0.5; 0.75; 1];
%ncoord = [0; 0.5; 1.0];
%ncoord = [0; 1];
%ncoord = [0; 0.25; 0.5; 0.75; 1];
%ncoord = [0.5 0.5; 1.5 0.5; 1.5 1.5; 0.5 1.5];
%ncoord=[0 0; 1 0; 1 1; 0 1; 0.5 0.5; 0.25 0.25; 0.25 0.75; 0.75 0.25; 0.75 0.75];
%ncoord = [0.0 0.0; 1.0 0.0; 1.0 1.0; 0.0 1.0];
%ncoord = [0.0 0.0; 0.5 0.0; 0.0 0.5; 0.5 0.5; 1.0 0.5; 0.0 1.0; 0.5 1.0; 1.0 1.0];
%ncoord = [0 0 0; 1 0 0; 1 1 0; 0 1 0; 0 0 1; 1 0 1; 1 1 1; 0 1 1];
%ncoord =  [0 0; 0 1.0000; 1.0000 0; 1.0000 1.0000; 0.3581  0; 0 0.5924; 0.3130 1.0000; 0.6686 0; ...
%           1.0000 0.3339; 0.5810 0.5883; 1.0000 0.7509; 0.5983 1.0000; 0.8192 1.0000; 0.8782 0; 1.0000 0.5619; 1.0000 0.8884];

% evaluation point
x = 0.211325;
%x = [0.25 0.25];
%x = [0.16666 0.5];
%x=[0.5 0.5];
%x = [0.25 0.25 0.25];
%x = [0.2 0.2];
%x = [0.665465 0.447852];
%x = [0.25 0.25];
%x = [0.35];
%x = [0.25 0.25 0.25];

% prior function data
rtol = 1e-8;                   % required tolerance for maxent iterations
prior_type = 'quartic_spline'; % 'quartic_spline', 'cubic_spline', 'gaussian' or 'constant'
compute = 2;                   % 1 for basis functions computation only, 2 for both, 
                               % basis functions and its gradient.
%gamma = 1.2;                  % support-width (dilation) parameter (needed only other than 'constant' prior)
                               % typical values for gamma:
                               % gaussian = 2 to 10
                               % quartic spline = 1 to 2
                               % cubic spline = 1 to 2
gamma = [1.2; 1.2; 1.2; 1.2; 1.2]; % Always a vector of size = number of nodes

% initial values for lagrange multipliers
ilambda = 0;             % 1D
%ilambda = [0; 0];         % 2D
%ilambda = [0; 0; 0];     % 3D

% specify if basis functions and gradients must be printed out
printmaxent = 'yes';  % 'yes' or 'no'

% specify if consistency check test for phi and phider must be done
checktest = 'yes'; % 'yes' or 'no'










