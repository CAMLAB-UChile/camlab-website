% function time=assembly3(xmin,xmax,ymin,ymax,divx,divy)
%
% Purpose
% =======                                                                      
% Assembly global stiffness matrix (K) of the 2D heat conduction problem on the 
% domain (xmin,xmax)x(ymin,ymax) of unit thickness. Dx=Dy=1 is assumed.
%
% Assembly method:  On using triplets I,J,X such that K(I(a),J(a)) = X(a), the 
% sparse matrix K of size nxn is built as 
% 
%                          K=sparse(I,J,X,n,n)
% 
% The X values of repeated pairs in I,J are added each other in Matlab sparse 
% function, which represents the assembly procedure.
%
% Variables
% =========
% xmin   : x-coordinate minimum value
% xmax   : x-coordinate maximum value
% ymin   : y-coordinate minimum value
% ymax   : y-coordinate maximum value
% divx   : number of divisions along x-direction
% divy   : number of divisions along y-direction
%
% Return
% ======
% time   : elapsed time of stiffness matrix assembly
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function time=assembly3(xmin,xmax,ymin,ymax,divx,divy)

% create uniform mesh of 3-node triangles
[ncoord,connect]=meshT3u(xmin,xmax,ymin,ymax,divx,divy);

numel=size(connect,1);         % number of elements
numnod=size(ncoord,1);         % number of nodes

% assembly
tic
I=zeros(9*numel,1);  % sizes of I,J,K valid for 3-node triangles only
J=zeros(9*numel,1); 
X=zeros(9*numel,1);
s=1;
for e=1:numel % loop over elements
  nodes=connect(e,:).';
  xy=ncoord(nodes,:);
  [x,w]=gausspoints(xy);
  for g=1:3 % loop over gauss points (3 per element: see gausspoints.m)
    [phi,phider]=shapefunctionsT3(xy,x(g,:));
    r=s;
    for j=1:3
      for k=1:3
        X(r)=X(r)+(phider(j,1)*phider(k,1)+phider(j,2)*phider(k,2))*w(g);
        r=r+1;
      end
    end
  end
  % fill in triplets (valid for 3-node triangles only)
  I(r-9)=nodes(1); I(r-8)=nodes(1); I(r-7)=nodes(1); 
  I(r-6)=nodes(2); I(r-5)=nodes(2); I(r-4)=nodes(2); 
  I(r-3)=nodes(3); I(r-2)=nodes(3); I(r-1)=nodes(3); 
  J(r-9)=nodes(1); J(r-8)=nodes(2); J(r-7)=nodes(3); 
  J(r-6)=nodes(1); J(r-5)=nodes(2); J(r-4)=nodes(3); 
  J(r-3)=nodes(1); J(r-2)=nodes(2); J(r-1)=nodes(3);
  s=s+9;
end

% create sparse K
K=sparse(I,J,X,numnod,numnod);
time=toc;





    
    
    







