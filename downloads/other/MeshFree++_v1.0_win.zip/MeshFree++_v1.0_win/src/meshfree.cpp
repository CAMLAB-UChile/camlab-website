/*******************************************************************************
*                               MeshFree++                                     *
*                               ==========                                     *
*                                                                              *
*   A C++ class that provides a unified meshfree basis function computation.   *
*                                                                              *
*  Created by  : Alejandro A. Ortiz                                            *
*  E-mail      : alortiz@ucdavis.edu                                           *
*  Version     : 1.0                                                           *
*  Date        : September 23, 2009                                            *
*                                                                              *
*                         Copyright and License                                *
*                         =====================                                *
*                                                                              *
*                   MeshFree++ 1.0, Copyright (c) 2009                         *
*                          by Alejandro A. Ortiz,                              *
*                           alortiz@ucdavis.edu                                *
*             Department of Civil & Environmental Engineering,                 *
*             University of California, Davis, CA 95616, U.S.A.                *
*                           All Rights Reserved.                               *
*                                                                              *
*    Your use or distribution of MeshFree++ Class or any derivative code       *
*    implies that you agree to this License.                                   *
*                                                                              *
*    This program is distributed in the hope that it will be useful,           *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. This program is      *
*    free software and you can choose any of the following license terms:      *
*                                                                              *
*    1) GNU Lesser General Public License (LGPL) as published by the Free      *
*       Software Foundation; either version 3 of the License, or(at your       *
*       option) any later version. For details see copy of LGPL in folder      *
*       License\gnu of this distribution.                                      *
*                                                                              *
*    2) Alternatively, you may choose to comply with the following             * 
*       UMFPACK-style license:                                                 *
*                                                                              *
*       THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY           *
*       EXPRESSED OR IMPLIED. ANY USE IS AT YOUR OWN RISK.                     *
*                                                                              *
*       Permission is hereby granted to use or copy this program, provided     * 
*       that the Copyright, this License, and the Availability of the          * 
*       original version is retained on all copies. User documentation of      *
*       any code that uses this code or any derivative code must cite the      * 
*       Copyright, this License, the Availability note, and "Used by           *
*       permission". Permission to modify the code and to distribute           * 
*       modified code is granted, provided the Copyright, this License,        * 
*       and the Availability note are retained, and a notice that the code     * 
*       was modified is included. This software is provided to you free of     * 
*       charge.                                                                * 
*                                                                              *
*    MeshFree++ uses MathVec++. You must comply with MathVec++ license terms.  * 
*    For details see folder License of this distribution.                      *
*                                                                              *
*------------------------------------------------------------------------------*  
*                                                                              *
* Release notes                                                                *	
* =============                                                                *
* Version 1.0 (September 23, 2009): Compute first order maximum entropy basis  *
* functions (maxent) and first order moving least squares basis functions      *
* (mls).                                                                       *
*                                                                              *
*------------------------------------------------------------------------------*
*                                                                              *
* References                                                                   *
* =============                                                                *
* [1] Sukumar N., Wright R.W. Overview and construction of meshfree shape      *
* functions: From moving least squares to entropy approximants. Int. J.        *
* Numer. Meth. Engng 2007; 70(2):181-205.                                      *
*                                                                              *
* [2] Arroyo M., Ortiz M. Local maximum-entropy approximation schemes: a       *
* semaless bridge between finite elements and meshfree methods. Int. J.        *
* Numer. Meth. Engng 2006; 65(13):2167-2202.                                   *
*                                                                              *
* [3] Dolbow J., Belytschko T. An introduction to programming the meshless     *
* element free Galerkin method. Arch. Comput. Methods Eng. 1998; 5(3):207-242. *
*                                                                              *
*******************************************************************************/

#include "meshfree.h"

/*******************************************************************************
*                                                                              *
*                         MESHFREE CLASS IMPLEMENTATION                        *
*                         =============================                        *
*                                                                              *
*******************************************************************************/

// constructors
MeshFree::
MeshFree(const string& name,
         int dim,
         int nNodes,
         const Mat<double>& nodeCoord,
         const Vec<double>& xSample,
         const Vec<double>& nodeSpacing,
         double gamma,
         int order,
         int compute,
         bool autoIncreaseSupportSize,
         bool variousSamplePoints)
{
  // initialize some private variables 
  name_ = name;
  dim_ = dim;
  nNodes_ = nNodes;
  nodeCoord_ = nodeCoord;
  xSample_ = xSample;
  nodeSpacing_ = nodeSpacing;
  gamma_ = gamma;
  order_ = order;
  compute_ = compute;
  autoIncreaseSupportSize_ = autoIncreaseSupportSize;
  variousSamplePoints_ = variousSamplePoints;
  // prepare output files
  if (variousSamplePoints == false)
  {
    ofstream outFile; 
    // delete previous meshfree output file
    outFile.open("meshfreeresults.txt");
    outFile.close();
    // delete previous message output file
    outFile.open("messages.txt");
    outFile.close();
  }
  // do some checks
  if ((int)nodeSpacing.size() < 2)
    constantNodeSpacing_ = 1; // constant node spacing
  else if ((int)nodeSpacing.size() != nNodes)
  {
    cout << endl;
    cout << "In " << name << " computation." << endl;
    cout << "WARNING: Size of ''nodeSpacing'' is neither 1 ";
    cout << "nor ''number of nodes''." << endl;
    cout << "Changing to constant node spacing. Using the maximum ";
    cout << "value in ''nodeSpacing''." << endl;
    cout << endl;
    ofstream outFile;
    outFile.open("messages.txt", ios::app);
    outFile << endl;
    outFile << "In " << name << " computation." << endl;
    outFile << "WARNING: Size of ''nodeSpacing'' is neither 1 ";
    outFile << "nor ''number of nodes''." << endl;
    outFile << "Changing to constant node spacing. Using the maximum ";
    outFile << "value in ''nodeSpacing''." << endl;
    outFile << endl;
    outFile.close();
    // change values
    constantNodeSpacing_ = 1; // constant node spacing
    nodeSpacing_ = Vec<double>(1,nodeSpacing.max());
  }
}

MeshFree::
MeshFree(const MeshFree& rhsObj)
{
  name_ = rhsObj.name_;
  dim_ = rhsObj.dim_;
  nNodes_ = rhsObj.nNodes_;
  nodeCoord_ = rhsObj.nodeCoord_;
  xSample_ = rhsObj.xSample_;
  nodeSpacing_ = rhsObj.nodeSpacing_;
  gamma_ = rhsObj.gamma_;
  order_ = rhsObj.order_;
  compute_ = rhsObj.compute_;
  autoIncreaseSupportSize_ = rhsObj.autoIncreaseSupportSize_;
  variousSamplePoints_ = rhsObj.variousSamplePoints_;
  constantNodeSpacing_ = rhsObj.constantNodeSpacing_;
  xShift_ = rhsObj.xShift_;
  weightFun_ = rhsObj.weightFun_;
  weightFunDer_ = rhsObj.weightFunDer_;
  phi_ = rhsObj.phi_;
  phiDer_ = rhsObj.phiDer_;
  contribute_ = rhsObj.contribute_;
  length_ = rhsObj.length_;
}

// assignment operator
const MeshFree& 
MeshFree::
operator=(const MeshFree& rhsObj)
{
  name_ = rhsObj.name_;
  dim_ = rhsObj.dim_;
  nNodes_ = rhsObj.nNodes_;
  nodeCoord_ = rhsObj.nodeCoord_;
  xSample_ = rhsObj.xSample_;
  nodeSpacing_ = rhsObj.nodeSpacing_;
  gamma_ = rhsObj.gamma_;
  order_ = rhsObj.order_;
  compute_ = rhsObj.compute_;
  autoIncreaseSupportSize_ = rhsObj.autoIncreaseSupportSize_;
  variousSamplePoints_ = rhsObj.variousSamplePoints_;
  constantNodeSpacing_ = rhsObj.constantNodeSpacing_;
  xShift_ = rhsObj.xShift_;
  weightFun_ = rhsObj.weightFun_;
  weightFunDer_ = rhsObj.weightFunDer_;
  phi_ = rhsObj.phi_;
  phiDer_ = rhsObj.phiDer_;
  contribute_ = rhsObj.contribute_;
  length_ = rhsObj.length_;
  return *this;
}

// destructor
MeshFree::~MeshFree()
{
}

// define class functions

/*******************************************************************************
* FUNCTION setPhi                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Set private variable: phi_                                                   *
*******************************************************************************/
//
void 
MeshFree::
setPhi(const Vec<double>& phi)
{
  phi_ = phi;
}

/*******************************************************************************
* FUNCTION setPhiDer                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Set private variable: phiDer_                                                *
*******************************************************************************/
//
void 
MeshFree::
setPhiDer(const Mat<double>& phiDer)
{
  phiDer_ = phiDer;
}

/*******************************************************************************
* FUNCTION setContribute                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Set private variable: contribute_                                            *
*******************************************************************************/
//
void 
MeshFree::
setContribute(const Vec<int>& contribute)
{
  contribute_ = contribute;
}

/*******************************************************************************
* FUNCTION setLength                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Set private variable: length_                                                *
*******************************************************************************/
//
void 
MeshFree::
setLength(int length)
{
  length_ = length;
}

/*******************************************************************************
* FUNCTION gaussian                                                            *
* Purpose                                                                      *
* =======                                                                      *
* Compute Gaussian weight (kernel) function provided the tolerance (Tol_0)     *
* at which Gaussian function is considered zero                                *
*******************************************************************************/
//
void 
MeshFree::
gaussian(double Tol_0)
{
  double beta;
  Vec<double> xShift_i;
  // compute shifted coordinates
  computeShiftedCoordinates();
  // compute prior
  if (constantNodeSpacing_)
  {
    // characteristic nodal spacing
    double h = nodeSpacing_.max();
    // weight (kernel) function radius
    Vec<double> radius(1,h * sqrt(-log(Tol_0) / gamma_));
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute Gaussian prior and its gradient
    beta = gamma_ / (h * h);
    for (int i = 0; i < length_; i++)
    {
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      weightFun_.push_back(exp(-beta * xShift_i.norm() * xShift_i.norm()));
      weightFunDer_.push_back(2.0 * beta * weightFun(i) * xShift_i);
    }
  }
  else // each node has its own node spacing
  {
    // weight (kernel) function radius
    Vec<double> radius = nodeSpacing_ * sqrt(-log(Tol_0) / gamma_);
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute Gaussian prior and its gradient
    for (int i = 0; i < length_; i++)
    {
      beta = gamma_ / (nodeSpacing_(i) * nodeSpacing_(i));
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      weightFun_.push_back(exp(-beta * xShift_i.norm() * xShift_i.norm()));
      weightFunDer_.push_back(2.0 * beta * weightFun(i) * xShift_i);
    } 
  }
}

/*******************************************************************************
* FUNCTION cubicSpline                                                         *
* Purpose                                                                      *
* =======                                                                      *
* Compute cubic spline weight (kernel) function                                *
*******************************************************************************/
//
void 
MeshFree::
cubicSpline()
{
  double dm;
  double q;
  Vec<double> xShift_i;
  // compute shifted coordinates
  computeShiftedCoordinates();
  // compute cubic spline
  if (constantNodeSpacing_)
  {
    // characteristic nodal spacing
    double h = nodeSpacing_.max();
    // weight (kernel) function radius
    Vec<double> radius(1, gamma_ * h);
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute cubic spline and its gradient
    for (int i = 0; i < length_; i++)
    {
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      dm = 1 / radius(0);
      q = xShift_i.norm() * dm;
      if (q <= 0.5)
      {
        weightFun_.push_back(2.0/3.0 - 4.0*q*q + 4.0*q*q*q);
        weightFunDer_.push_back(dm*dm*(8-12*q) * xShift_i);
      }
      else
      {
        weightFun_.push_back(4.0/3.0 - 4.0*q + 4.0*q*q - 4.0*q*q*q/3.0);
        weightFunDer_.push_back(dm*dm*(4.0/q - 8.0 + 4.0*q) * xShift_i);
      }
    }
  }
  else // each node has its own node spacing
  {
    // weight (kernel) function radius
    Vec<double> radius = gamma_ * nodeSpacing_;
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute cubic spline and its gradient
    for (int i = 0; i < length_; i++)
    {
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      dm = 1 / radius(i);
      q = xShift_i.norm() * dm;
      if (q <= 0.5)
      {
        weightFun_.push_back(2.0/3.0 - 4.0*q*q + 4.0*q*q*q);
        weightFunDer_.push_back(dm*dm*(8-12*q) * xShift_i);
      }
      else
      {
        weightFun_.push_back(4.0/3.0 - 4.0*q + 4.0*q*q - 4.0*q*q*q/3.0);
        weightFunDer_.push_back(dm*dm*(4.0/q - 8.0 + 4.0*q) * xShift_i);
      }
    }
  }
}

/*******************************************************************************
* FUNCTION quarticSpline                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Compute quartic spline weight (kernel) function                              *
*******************************************************************************/
//
void
MeshFree::
quarticSpline()
{
  double dm;
  double q;
  Vec<double> xShift_i;
  // compute shifted coordinates
  computeShiftedCoordinates();
  // compute quartic spline
  if (constantNodeSpacing_)
  {
    // characteristic nodal spacing
    double h = nodeSpacing_.max();
    // weight (kernel) function radius
    Vec<double> radius(1, gamma_ * h);
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute quartic spline and its gradient
    for (int i = 0; i < length_; i++)
    {
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      dm = 1 / radius(0);
      q = xShift_i.norm() * dm;
      weightFun_.push_back(1.0 - 6.0*q*q + 8.0*q*q*q - 3.0*q*q*q*q);
      weightFunDer_.push_back(dm*dm*(12.0 - 24.0*q + 12.0*q*q) * xShift_i);
    }
  }
  else // each node has its own node spacing
  {
    // weight (kernel) function radius
    Vec<double> radius = gamma_ * nodeSpacing_;
    // find neighbors contributing at xSample_
    neighbors(radius);
    // compute quartic spline and its gradient
    for (int i = 0; i < length_; i++)
    {
      xShift_i = xShift_.getRow(contribute_(i) + 1);
      dm = 1 / radius(i);
      q = xShift_i.norm() * dm;
      weightFun_.push_back(1.0 - 6.0*q*q + 8.0*q*q*q - 3.0*q*q*q*q);
      weightFunDer_.push_back(dm*dm*(12.0 - 24.0*q + 12.0*q*q) * xShift_i);
    }
  }
}

/*******************************************************************************
* FUNCTION constantWeight()                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Set weight (kernel) function to all entries = 1 and its gradient to all      *
* all entries = 0                                                              *
*******************************************************************************/
//
void 
MeshFree::
constantWeight()
{
  // compute shifted coordinates
  computeShiftedCoordinates();
  // compute constant weights
  weightFun_ = Vec<double>(nNodes_,1.0);
  weightFunDer_ = Mat<double>(nNodes_,dim_,0.0);
  contribute_ = Vec<int>(nNodes_);
  for (int i = 0; i < nNodes_; i++)
    contribute_(i) = i;
  length_ = contribute_.size();
}

/*******************************************************************************
* FUNCTION name                                                                *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: name_                                               *
*******************************************************************************/
//
const string 
MeshFree::
name() const
{
  return name_;
}

/*******************************************************************************
* FUNCTION dim                                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: dim_                                                *
*******************************************************************************/
//
int 
MeshFree::
dim() const
{
  return dim_;
}

/*******************************************************************************
* FUNCTION nNodes                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: nNodes_                                             *
*******************************************************************************/
//
int 
MeshFree::
nNodes() const
{
  return nNodes_;
}

/*******************************************************************************
* FUNCTION gamma                                                               *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: gamma_                                              *
*******************************************************************************/
//
double 
MeshFree::
gamma() const
{
  return gamma_;
}

/*******************************************************************************
* FUNCTION order                                                               *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: order_                                              *
*******************************************************************************/
//
int 
MeshFree::
order() const
{
  return order_;
}

/*******************************************************************************
* FUNCTION compute                                                             *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: compute_                                            *
*******************************************************************************/
//
int 
MeshFree::
compute() const
{
  return compute_;
}

/*******************************************************************************
* FUNCTION variousSamplePoints                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: variousSamplePoints_                                *
*******************************************************************************/
//
bool 
MeshFree::
variousSamplePoints() const
{
  return variousSamplePoints_;
}

/*******************************************************************************
* FUNCTION nodeSpacing                                                         *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: nodeSpacing_                            *
*******************************************************************************/
//
double 
MeshFree::
nodeSpacing(int index) const
{
  return nodeSpacing_(index);
}

/*******************************************************************************
* FUNCTION nodeSpacing                                                         *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: nodeSpacing_                                        *
*******************************************************************************/
//
const Vec<double> 
MeshFree::
nodeSpacing() const
{
  return nodeSpacing_;
}

/*******************************************************************************
* FUNCTION nodeCoord                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: nodeCoord_                              *
*******************************************************************************/
//
double 
MeshFree::
nodeCoord(int index_i,
          int index_j) const
{
  return nodeCoord_(index_i,index_j);
}

/*******************************************************************************
* FUNCTION nodeCoordContribute                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable nodeCoord_ that are in the neighbor      * 
* (contribute) list                                                            *
*******************************************************************************/
//
double 
MeshFree::
nodeCoordContribute(int index_i,
                    int index_j) const
{
  return nodeCoord_(contribute_(index_i),index_j);
}

/*******************************************************************************
* FUNCTION nodeCoord                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: nodeCoord_                                          *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
nodeCoord() const
{
  return nodeCoord_;
}

/*******************************************************************************
* FUNCTION nodeCoordContribute                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable nodeCoord_ with information only for the nodes that  *
* are in the neighbor (contributing) list                                      *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
nodeCoordContribute() const
{
  Mat<double> temp(length_,dim_);
  for (int i = 0; i < length_; i++)
    for (int j = 0; j < dim_; j++)
      temp(i,j) = nodeCoord_(contribute_(i),j);
  return temp;
}

/*******************************************************************************
* FUNCTION xSample                                                             *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: xSample_                                *
*******************************************************************************/
//
double 
MeshFree::
xSample(int index) const
{
  return xSample_(index);
}

/*******************************************************************************
* FUNCTION xSample                                                             *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: xSample_                                            *
*******************************************************************************/
//
const Vec<double> 
MeshFree::
xSample() const
{
  return xSample_;
}

/*******************************************************************************
* FUNCTION xShift                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: xShift_                                 *
*******************************************************************************/
//
double 
MeshFree::
xShift(int index_i,
       int index_j) const
{
  return xShift_(index_i,index_j);
}

/*******************************************************************************
* FUNCTION xShiftContribute                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable xShift_ that are in the neighbor         * 
* (contribute) list                                                            *
*******************************************************************************/
//
double 
MeshFree::
xShiftContribute(int index_i,
                 int index_j) const
{
  return xShift_(contribute_(index_i),index_j);
}

/*******************************************************************************
* FUNCTION xShift                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: xShift_                                             *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
xShift() const
{
  return xShift_;
}

/*******************************************************************************
* FUNCTION xShiftContribute                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable xShift_ with information only for the nodes that are *
* in the neighbor (contributing) list                                          *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
xShiftContribute() const
{
  Mat<double> temp(length_,dim_);
  for (int i = 0; i < length_; i++)
    for (int j = 0; j < dim_; j++)
      temp(i,j) = xShift_(contribute_(i),j);
  return temp;
}

/*******************************************************************************
* FUNCTION phi                                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: phi_                                    *
*******************************************************************************/
//
double 
MeshFree::
phi(int index) const
{
  return phi_(index);
}

/*******************************************************************************
* FUNCTION phi                                                                 *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: phi_                                                *
*******************************************************************************/
//
const Vec<double> 
MeshFree::
phi() const
{
  return phi_;
}

/*******************************************************************************
* FUNCTION phiDer                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: phiDer_                                 *
*******************************************************************************/
//
double 
MeshFree::
phiDer(int index_i,
       int index_j) const
{
  return phiDer_(index_i,index_j);
}

/*******************************************************************************
* FUNCTION phiDer                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: phiDer_                                             *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
phiDer() const
{
  return phiDer_;
}

/*******************************************************************************
* FUNCTION contribute                                                          *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: contribute_                             *
*******************************************************************************/
//
int 
MeshFree::
contribute(int index) const
{
  return contribute_(index);
}

/*******************************************************************************
* FUNCTION contribute                                                          *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: contribute_                                         *
*******************************************************************************/
//
const Vec<int> 
MeshFree::
contribute() const
{
  return contribute_;
}

/*******************************************************************************
* FUNCTION length                                                              *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: length_                                             *
*******************************************************************************/
//
int 
MeshFree::
length() const
{
  return length_;
}

/*******************************************************************************
* FUNCTION weightFun                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: weightFun_                              *
*******************************************************************************/
//
double 
MeshFree::
weightFun(int index) const
{
  return weightFun_(index);
}

/*******************************************************************************
* FUNCTION weightFun                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: weightFun_                                          *
*******************************************************************************/
//
const Vec<double> 
MeshFree::
weightFun() const
{
  return weightFun_;
}

/*******************************************************************************
* FUNCTION weightFunDer                                                        *
* Purpose                                                                      *
* =======                                                                      *
* Return elements of private variable: weightFunDer_                           *
*******************************************************************************/
//
double 
MeshFree::
weightFunDer(int index_i,
             int index_j) const
{
  return weightFunDer_(index_i,index_j);
}

/*******************************************************************************
* FUNCTION weightFunDer                                                        *
* Purpose                                                                      *
* =======                                                                      *
* Return private variable: weightFunDer_                                       *
*******************************************************************************/
//
const Mat<double> 
MeshFree::
weightFunDer() const
{
  return weightFunDer_;
}

/*******************************************************************************
* FUNCTION computeShiftedCoordinates                                           *
* Purpose                                                                      *
* =======                                                                      *
* Compute shifted nodal coordinates                                            *
*******************************************************************************/
//
void
MeshFree::
computeShiftedCoordinates()
{
  xShift_ = Mat<double>(nNodes_,dim_);
  for (int i = 0; i < nNodes_; i++)
    for (int j = 0; j < dim_; j++)
      xShift_(i,j) = nodeCoord_(i,j) - xSample_(j); 
}

/*******************************************************************************
* FUNCTION neighbors                                                           *
* Purpose                                                                      *
* =======                                                                      *
* Compute neighbors (contributing nodes) at evaluation point (xSample)         *
*******************************************************************************/
//
void
MeshFree::
neighbors(const Vec<double>& radius)
{
  // Note: The radius depends on nodal spacing, so the code below will depend
  // on whether it is constant or not. The code below is a naive implementation
  // which is of Order(nNodes_). A better approach is to use kd-tree techniques 

  Vec<double> xShift_i(dim_);
  if (autoIncreaseSupportSize_)
  {
    double dr = 1.0;    // % increment of support radius
    bool isTrue = true;
    while (isTrue)
    {
      if (constantNodeSpacing_)
      {
        for (int i = 0; i < nNodes_; i++)
        {
          xShift_i = xShift_.getRow(i+1);
          if (xShift_i.norm() < (radius(0) * dr))
            contribute_.push_back(i);
        }
      }
      else // variable nodal spacing
      {
        for (int i = 0; i < nNodes_; i++)
        {
          xShift_i = xShift_.getRow(i+1);
          if (xShift_i.norm() < (radius(i) * dr))
            contribute_.push_back(i);
        }
      }
      length_ = contribute_.size();
      if (length_ < (dim_ + 1))
      {
        cout << "WARNING: Not enough neighbors for sample point: " << xSample_; 
        cout <<". Automatically increasing the support radius by 10%." << endl;
        cout << endl;
        ofstream outFile; 
        outFile.open("messages.txt", ios::app);
        outFile << "WARNING: Not enough neighbors for sample point: " << xSample_; 
        outFile <<". Automatically increasing the support radius by 10%." << endl;
        outFile << endl;
        outFile.close();
        // increase radius
        dr *= 1.1;
        // remove all elements that were "push_back"
        contribute_.clear(); 
      }
      else
      {
        isTrue = false;
      }
    }
  }
  else
  {
    if (constantNodeSpacing_)
    {
      for (int i = 0; i < nNodes_; i++)
      {
        xShift_i = xShift_.getRow(i+1);
        if (xShift_i.norm() < radius(0))
        {
          contribute_.push_back(i);
        }
      }
    }
    else // variable nodal spacing
    {
      for (int i = 0; i < nNodes_; i++)
      {
        xShift_i = xShift_.getRow(i+1);
        if (xShift_i.norm() < radius(i))
        {
          contribute_.push_back(i);
        }
      }
    }
    length_ = contribute_.size();
    if (length_ < (dim_ + 1))
    {
      cout << "ERROR: Not enough neighbors for sample point " << xSample_; 
      cout <<". Increase support radius." << endl;
      cout << endl;
      ofstream outFile;
      outFile.open("messages.txt", ios::app);
      outFile << "ERROR: Not enough neighbors for sample point " << xSample_; 
      outFile <<". Increase support radius." << endl;
      outFile << endl;
      outFile.close();
      exit(1);    
    }
  }
}

/*******************************************************************************
* FUNCTION consistencyCheck                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Check if phi and phiDer were correctly computed                              *
*******************************************************************************/
//
void
MeshFree::
consistencyCheck() const
{	
  double tol = 5.0*(numeric_limits<double>::epsilon());
  // contributing xShift matrix
  Mat<double> xs = xShiftContribute();
  // print out on the screen
  cout << "*****************************************************\n";
  cout << "***************** CONSISTENCY CHECK *****************\n";
  cout << "*****************************************************\n";
  cout.setf(ios::scientific);
  cout.setf(ios::showpoint);
  cout.precision(6);
  // partition of unity consistency
  if (abs(phi_.sum() - 1.0) > tol)
  {
    cout << "WARNING: PU consistency error: " << endl;
    cout << "abs( Sum_i=1^n{phi_i} - 1 ) = " << abs(phi_.sum() - 1.0) << endl;
  }
  else
  {
    cout << "PU consistency check OK." << endl;
  }
  // approx. and derivative consistency check
  if (order_ == 1)
  {
    // approx. order consistency check
    Vec<double> approxCoord = phi_ * xs;
    if (approxCoord.norm() > tol)
    {
      cout << "WARNING: Linear consistency error: " << endl;
      cout << "norm[ Sum_i=1^n{phi_i*(x_i-x) ] = " << approxCoord.norm() << endl;
    }
    else
    {
      cout << "Linear consistency check OK." << endl;
    }
    if (compute_ == 2)
    {
      // derivative constant consistency check
      Vec<double> sumDer(dim_);
      for (int i = 0; i < dim_; i++)
        sumDer(i) = phiDer_.sumCol(i+1);
      if (sumDer.norm() > tol)
      {
        cout << "WARNING: Derivative constant consistency error: " << endl;
        cout << "norm[ Sum_i=1^n{Grad(phi_i)} ] = " << sumDer.norm() << endl;
      }
      else
      {
        cout << "Derivative constant consistency check OK." << endl;
      }
      // derivative linear consistency check
      Vec<double> auxVec(dim_*dim_);
      int k = 0;
      for (int i = 0; i < dim_; i++)
      {
        for (int j = 0; j < dim_; j++)
        {
          auxVec(k) = phiDer_.getCol(i+1) * xs.getCol(j+1);
          if (i == j) auxVec(k) -= 1.0;
            k++;
        }
      }
      if (auxVec.norm() > tol)
      {
        cout << "WARNING: Derivative linear consistency error: " << endl;
        cout << "norm[ Sum_i=1^n{Grad(phi_i)(X)(x_i - x)} ] = " << auxVec.norm() << endl;
      }
      else
      {
        cout << "Derivative linear consistency check OK." << endl;
      }
    }
    cout << endl;
    cout.unsetf(ios::scientific);
  }
  else
  {
    // code here for order > 1
  }
  // print out to output file
  ofstream outFile;
  outFile.open("meshfreeresults.txt", ios::app);
  outFile << "*****************************************************\n";
  outFile << "***************** CONSISTENCY CHECK *****************\n";
  outFile << "*****************************************************\n";
  outFile.setf(ios::scientific);
  outFile.setf(ios::showpoint);
  outFile.precision(6);
  // partition of unity consistency
  if (abs(phi_.sum() - 1.0) > tol)
  {
    outFile << "WARNING: PU consistency error: " << endl;
    outFile << "abs( Sum_i=1^n{phi_i} - 1 ) = " << abs(phi_.sum() - 1.0) << endl;
  }
  else
  {
    outFile << "PU consistency check OK." << endl;
  }
  // approx. and derivative consistency check
  if (order_ == 1)
  {
    // approx. order consistency check
    Vec<double> approxCoord = phi_ * xs;
    if (approxCoord.norm() > tol)
    {
      outFile << "WARNING: Linear consistency error: " << endl;
      outFile << "norm[ Sum_i=1^n{phi_i*(x_i-x) ] = " << approxCoord.norm() << endl;
    }
    else
    {
      outFile << "Linear consistency check OK." << endl;
    }
    if (compute_ == 2)
    {
      // derivative constant consistency check
      Vec<double> sumDer(dim_);
      for (int i = 0; i < dim_; i++)
        sumDer(i) = phiDer_.sumCol(i+1);
      if (sumDer.norm() > tol)
      {
        outFile << "WARNING: Derivative constant consistency error: " << endl;
        outFile << "norm[ Sum_i=1^n{Grad(phi_i)} ] = " << sumDer.norm() << endl;
      }
      else
      {
        outFile << "Derivative constant consistency check OK." << endl;
      }
      // derivative linear consistency check
      Vec<double> auxVec(dim_*dim_);
      int k = 0;
      for (int i = 0; i < dim_; i++)
      {
        for (int j = 0; j < dim_; j++)
        {
          auxVec(k) = phiDer_.getCol(i+1) * xs.getCol(j+1);
          if (i == j) auxVec(k) -= 1.0;
          k++;
        }
      }
      if (auxVec.norm() > tol)
      {
        outFile << "WARNING: Derivative linear consistency error: " << endl;
        outFile << "norm[ Sum_i=1^n{Grad(phi_i)(X)(x_i - x)} ] = " << auxVec.norm() << endl;
      }
      else
      {
        outFile << "Derivative linear consistency check OK." << endl;
      }
    }
    outFile << endl;
  }
  else
  {
    // code here for order > 1
  }
  // close output file
  outFile.close(); 
}

/*******************************************************************************
*                                                                              *
*                          MAXENT CLASS IMPLEMENTATION                         *
*                          ===========================                         *
*                                                                              *
*******************************************************************************/

// constructors 
Maxent::
Maxent(int dim, 
       int nNodes, 
       const Mat<double>& nodeCoord,
       const Vec<double>& xSample, 
       const Vec<double>& nodeSpacing,
       const string& weightName, 
       double gamma, 
       int order, 
       int compute,
       bool autoIncreaseSupportSize, 
       bool forceConsistencyCheck,
       bool variousSamplePoints, 
       bool printAllResults,
       double rtol, 
       int maxIter)
: MeshFree("maxent",dim,nNodes,nodeCoord,xSample,nodeSpacing,gamma,
           order,compute,autoIncreaseSupportSize,variousSamplePoints)
{
  // initialize some private variables
  weightName_ = weightName;
  forceConsistencyCheck_ = forceConsistencyCheck;
  printAllResults_ = printAllResults;
  rtol_ = rtol;
  maxIter_ = maxIter;
  failure_ = 0;
  newtonIter_ = 0;
  newtonError_ = 100.0;
  // do some checks
  if (dim > 3)
  {
    cout << "ERROR: Problem dimension greater than 3 is not available" << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Problem dimension greater than 3 is not available" << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if (order > 1)
  {
    cout << "ERROR: Approximation order greater than 1 is not available for ";
    cout << "maxent basis functions" << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Approximation order greater than 1 is not available for ";
    outFile << "maxent basis functions" << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ( (compute != 1) && (compute != 2))
  {
    cout << "ERROR: variable ''compute'' must be either 1 or 2." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: variable ''compute'' must be either 1 or 2." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)nodeCoord.cols() != dim)
  {
    cout << "ERROR: Dimension of nodal coordinates does not "; 
    cout << "coincide with problem dimension." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Dimension of nodal coordinates does not "; 
    outFile << "coincide with problem dimension." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)nodeCoord.rows() != nNodes)
  {
    cout << "ERROR: Number of nodes does not "; 
    cout << "coincide with number of rows of coordinate matrix." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Number of nodes does not "; 
    outFile << "coincide with number of rows of coordinate matrix." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)xSample.size() != dim)
  {
    cout << "ERROR: Dimension of sample point does not "; 
    cout << "coincide with problem dimension." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Dimension of sample point does not "; 
    outFile << "coincide with problem dimension." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if (forceConsistencyCheck && (!printAllResults))
  {
    cout << "printAllResults was changed to TRUE "; 
    cout << "in order to force consistency check." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "printAllResults was changed to TRUE "; 
    outFile << "in order to force consistency check." << endl;
    outFile << endl;
    outFile.close();
    // change value
    printAllResults_ = 1;
  }
}

Maxent::
Maxent(const Maxent& rhsObj)
: MeshFree(rhsObj)
{
  weightName_ = rhsObj.weightName_;
  forceConsistencyCheck_ = rhsObj.forceConsistencyCheck_;
  printAllResults_ = rhsObj.printAllResults_;
  rtol_ = rhsObj.rtol_;
  maxIter_ = rhsObj.maxIter_;
  failure_ = rhsObj.failure_;
  newtonIter_ = rhsObj.newtonIter_;
  newtonError_ = rhsObj.newtonError_;
  newtonLambda_ = rhsObj.newtonLambda_;
}

// assignement operator
const Maxent& 
Maxent::
operator=(const Maxent& rhsObj)
{
  weightName_ = rhsObj.weightName_;
  forceConsistencyCheck_ = rhsObj.forceConsistencyCheck_;
  printAllResults_ = rhsObj.printAllResults_;
  rtol_ = rhsObj.rtol_;
  maxIter_ = rhsObj.maxIter_;
  failure_ = rhsObj.failure_;
  newtonIter_ = rhsObj.newtonIter_;
  newtonError_ = rhsObj.newtonError_;
  newtonLambda_ = rhsObj.newtonLambda_;
  return *this;
}

// destructor
Maxent::~Maxent()
{
}

// define class functions

/*******************************************************************************
* FUNCTION computeMeshfree                                                     *
* Purpose                                                                      *
* =======                                                                      *
* Drive and manage the entire maxent computation.                              *
*******************************************************************************/
//
void
Maxent::
computeMeshfree()
{  
  // compute prior function
  computeWeight();
  // compute basis function and its gradient
  if (this->compute() == 1)
  {
    Vec<double> phi(this->length());
    computePhi(phi);
    this->setPhi(phi);
  }
  else if (this->compute() == 2)
  {
    Vec<double> phi(this->length());
    computePhi(phi);
    Mat<double> phiDer(this->length(),this->dim());
    computePhiDer(phi,phiDer);
    this->setPhi(phi);
    this->setPhiDer(phiDer);
  }
  // print maxent results
  printResults();
}

/*******************************************************************************
* FUNCTION computeWeight                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Compute prior weight function and find the neighbors (contributing nodes     *
* at evaluation point)                                                         *
*******************************************************************************/
//
void
Maxent::
computeWeight()
{
  // will compute and set weightFun_, weightFunDer_, contribute_ and length_
  // and shifted coordinates in the base class private variables
  if (weightName_ == "gaussian") 
    this->gaussian(rtol_);
  else if (weightName_ == "cubic")
    this->cubicSpline();
  else if (weightName_ == "quartic")
    this->quarticSpline();
  else if (weightName_ == "constant")
    this->constantWeight();
  else
  {
    cout << "ERROR: " << weightName_;
    cout << " weight (kernel) function is not available." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: " << weightName_;
    outFile << " weight (kernel) function is not available." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
}

/*******************************************************************************
* FUNCTION computePhi                                                          *
* Purpose                                                                      *
* =======                                                                      *
* Compute maxent basis functions                                               *
*******************************************************************************/
//
void
Maxent::
computePhi(Vec<double>& phi)
{
  // Newton's iterations: dlambda = -(Jacobian^-1)*Residual 
  // In maxent context:   Jacobian = Hessian matrix = H; 
  //                      Residual = - sum_{i=1^n}[phi_i*xShift_i]
  double alpha = 1.0;                     // constant to use in Newton's method with line search minimization
  Vec<double> lambda(this->dim(),0.0);    // set initial value to null vector
  Vec<double> dlambda(this->dim(),0.0);   // increment in lambda
  Vec<double> residual(this->dim(),1.0);  // residual vector: set initial value to unit vector
  Mat<double> jacobian(this->dim(),this->dim()); // hessian matrix in maxent context
  failure_ = 0; // no failure
  int nIter = 0;
  while ( (residual.norm() > rtol_) && (nIter <= maxIter_) )
  {
    functionOfLambda(lambda,residual,jacobian,phi);
    if ( abs(1.0 / jacobian.smallCond1()) < 1e-5 )
	  { 
	    if ( !(residual.norm() > 0.0) ) // exit if residual.norm() = NaN
      {
        cout << "In maxent computation." << endl;
        cout << "EVALUATION POINT: " << this->xSample() << endl;
        cout << "In Newton's iterations, Jacobian is singular." << endl;
        cout << endl;
        ofstream outFile;
        outFile.open("messages.txt", ios::app);
        outFile << "In maxent computation." << endl;
        outFile << "EVALUATION POINT: " << this->xSample() << endl;
        outFile << "In Newton's iterations, Jacobian is singular." << endl;
        outFile << endl;
        outFile.close();
        exit(1);
      } 
      cout << "In maxent computation." << endl;
      cout << "EVALUATION POINT: " << this->xSample() << endl;
	    cout << "WARNING: in Newton's iterations, nearly singular Jacobian." << endl;
      cout << endl;
      ofstream outFile;
      outFile.open("messages.txt", ios::app);
      outFile << "In maxent computation." << endl;
      outFile << "EVALUATION POINT: " << this->xSample() << endl;
      outFile << "WARNING: in Newton's iterations, nearly singular Jacobian." << endl;
      outFile << endl;
      outFile.close();
	  }
	  // compute lambda increment
	  dlambda = -(jacobian.smallInv() * residual);
	  // compute step size
	  if (residual.norm() < 1.0e-4)
	    alpha = 1.0;
	  else
	    alpha = stepSize(rtol_,lambda,dlambda);
	  // update solution
	  lambda = lambda + alpha * dlambda;
	  // count iterations
	  nIter++;
  }
  // check final Newton tolerance
  if (residual.norm() > rtol_)
    failure_ = 1; // failure: nIter > maxIter_
  // set the number of iterations to converge or non-convergence
  newtonIter_ = nIter;
  // set the final residual error of Newton's method
  newtonError_ = residual.norm();
  // set the final (converged or non-converged) lagrange multipliers
  newtonLambda_ = lambda - alpha * dlambda;
}

/*******************************************************************************
* FUNCTION functionOfLambda                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Compute all quantities that depend on current lambda in the Newton's         * 
* iterations                                                                   *
*******************************************************************************/
//
void
Maxent::
functionOfLambda(const Vec<double>& lambda,
                 Vec<double>& residual,
                 Mat<double>& jacobian,
                 Vec<double>& phi) const
{
  // get shifted coordinates from base class
  Mat<double> xs = this->xShiftContribute();
  // partition function components
  Vec<double> zi = -(xs * lambda);
  for (int i = 0; i < this->length(); i++)
    zi(i) = this->weightFun(i) * exp(zi(i));
  // partition function
  double z = zi.sum();
  // maxent basis functions
  phi = zi / z;
  // Newton's residual (-sum_{i=1^n}[phi_i*xShift_i] in maxent context)
  for (int i = 0; i < this->dim(); i++)
    residual(i) = -(xs.getCol(i+1) * phi);
  // Jacobian (Hessian matrix H in maxent context)
  Vec<double> xsi(this->length());
  for (int i = 0; i < this->dim(); i++)
  {
    xsi = xs.getCol(i+1);
    for (int k = 0; k < this->length(); k++)
	  xsi(k) *= phi(k);
    for (int j = 0; j < this->dim(); j++)
	  jacobian(i,j) = xsi * xs.getCol(j+1);
  }
}

/*******************************************************************************
* FUNCTION stepSize                                                            *
* Purpose                                                                      *
* =======                                                                      *
* Compute step size for backtracing in the line search scheme used in Newton's *
* method                                                                       *
*                                                                              *
* References                                                                   *
* ==========                                                                   *
* [1] Burden R.L., Faires J.D. Numerical Analysis, 8th Edition, Thompson       *
* Brooks Cole, 2005.                                                           * 
* [2] Press H.P., Teukolsky S.A., Vetterling W.T., Flannery B.P. Numerical     * 
* Recipes, The Art of Scientific Computing, 3rd Edition, Cambridge University  * 
* Press, 2007.                                                                 *
*******************************************************************************/
//
double 
Maxent::
stepSize(const double rtol_,
         const Vec<double>& lambda,
         const Vec<double>& dlambda) const
{
  // tolerance at which a double number is considered 0
  double tol_0 = 2.0*(numeric_limits<double>::epsilon()); 
  // test alpha's
  double alpha1 = 0.0;
  double alpha2 = 0.0;
  double alpha3 = 0.0;
  double alpha;
  // first try full Newton step
  alpha3 = 1.0;
  Vec<double> lambda_f = lambda;
  Vec<double> lambda_u = lambda;
  double g1 = dualObjectiveFunction(lambda_u);
  lambda_u = lambda_f + alpha3 * dlambda;
  double g3 = dualObjectiveFunction(lambda_u);
  // find alpha if full Newton step is not adequate
  while ( (g3 > g1) && (alpha3 > 0.5 * rtol_) )
  {
    alpha3 = 0.5 * alpha3;
	lambda_u = lambda_f + alpha3 * dlambda;
	g3 = dualObjectiveFunction(lambda_u);
  }
  if (alpha3 > 0.5 * rtol_)
  {
    alpha2 = 0.5 * alpha3;
	lambda_u = lambda_f + alpha2 * dlambda;
	double g2 = dualObjectiveFunction(lambda_u);
	double h1 = (g2 - g1) / alpha2;
	double h2 = (g3 - g2) / (alpha3 - alpha2);
	double h3 = (h2 - h1) / alpha3;
    if (abs(h3 - 0.0) > tol_0)
	  alpha1 = 0.5 * (alpha2 - h1 / h3);
    else
      alpha1 = alpha3;
    lambda_u = lambda_f + alpha1 * dlambda;
    double g0 = dualObjectiveFunction(lambda_u);
    if (g0 < g3)
      alpha = alpha1;
    else
      alpha = alpha3;
  }
  else
    alpha = alpha3;
  return alpha;
}

/*******************************************************************************
* FUNCTION dualObjectiveFunction                                               *
* Purpose                                                                      *
* =======                                                                      *
* Compute the objective function of the maxent dual: log(Z)                    *
*******************************************************************************/
//
double
Maxent::
dualObjectiveFunction(const Vec<double>& lambda) const
{
  // get shifted coordinates from base class
  Mat<double> xs = this->xShiftContribute(); 
  // partition function components
  Vec<double> zi = -(xs * lambda); 
  for (int i = 0; i < this->length(); i++)
    zi(i) = this->weightFun(i) * exp(zi(i));
  // partition function
  double z = zi.sum(); 
  // return objective function
  return log(z);
}

/*******************************************************************************
* FUNCTION computePhiDer                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Compute the gradient of maxent basis functions. An example in 2D is:         *
*                                                                              *
* phiDer = [ ... ... ; der_x  der_y; ... ...]                                  *
* where the entries are computed from:                                         *
* [der_x der_y]_i = phi_i*(\tilde{x}_i*(invH-invH*A)+MA_i-mc)                  *
*******************************************************************************/
//
void
Maxent::
computePhiDer(const Vec<double>& phi,
              Mat<double>& phiDer) const
{
  // get shifted coordinates from base class
  Mat<double> xs = this->xShiftContribute(); 
  // compute matrices
  Mat<double> MA(this->length(),this->dim());
  Mat<double> H(this->dim(),this->dim());
  Mat<double> A(this->dim(),this->dim()); 
  Vec<double> mc(this->dim());
  phiDerMatrices(phi,MA,H,A,mc); 
  // compute gradient of maxent basis functions
  Mat<double> invH = H.smallInv();
  phiDer = xs * (invH - invH * A) + MA;
  for (int i = 0; i < this->length(); i++)
    for (int j = 0; j < this->dim(); j++)
	  phiDer(i,j) = phi(i) * phiDer(i,j) - phi(i) * mc(j);
}

/*******************************************************************************
* FUNCTION phiDerMatrices                                                      *
* Purpose                                                                      *
* =======                                                                      *
* Compute matrices needed to compute the gradient of maxent basis functions    *
*******************************************************************************/
//
void
Maxent::
phiDerMatrices(const Vec<double>& phi,
               Mat<double>& MA,
               Mat<double>& H,
               Mat<double>& A,
               Vec<double>& mc) const
{
  // get shifted coordinates from base class
  Mat<double> xs = this->xShiftContribute(); 
  Vec<double> xsi(this->length()); // column "i" of xs
  // compute MA matrix
  for (int i = 0; i < this->length(); i++)
    for (int j = 0; j < this->dim(); j++)
      MA(i,j) = (1 / this->weightFun(i)) * this->weightFunDer(i,j);
  // compute the Hessian matrix (H) and A matrix
  for (int i = 0; i < this->dim(); i++)
  {
    xsi = xs.getCol(i+1);
    for (int k = 0; k < this->length(); k++)
      xsi(k) *= phi(k);
    for (int j = 0; j < this->dim(); j++)
    {
      H(i,j) = xsi * xs.getCol(j+1);
      A(i,j) = xsi * MA.getCol(j+1);
    }
  }
  // compute mc vector
  for (int i = 0; i < this->dim(); i++)
    mc(i) = phi * MA.getCol(i+1);
}

/*******************************************************************************
* FUNCTION printResults                                                        *
* Purpose                                                                      *
* =======                                                                      *
* Print a summary of maxent computations                                       *
*******************************************************************************/
//
void
Maxent::
printResults()
{
  if ( (!failure_) && printAllResults_)
  { 
	  // print out on the screen
	  cout << "*****************************************************\n";
	  cout << "************ MAXENT COMPUTATION SUMMARY *************\n";
	  cout << "*****************************************************\n";
	  cout.setf(ios::fixed);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "EVALUATION POINT: " << this->xSample() << endl;
    cout << "APPROX. ORDER: " << this->order() << endl;
	  cout.unsetf(ios::fixed);
	  cout << "PRIOR FUNCTION: " << weightName_ << endl;
    cout << "NODE SPACING: " << this->nodeSpacing() << endl;
	  cout << "GAMMA: " << this->gamma() << endl;
	  cout << "CONVERGENCE ATTAINED IN " << newtonIter_ <<" ITERATIONS\n";
	  cout.setf(ios::scientific);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "REQUIRED TOLERANCE = " << rtol_ << endl;
	  cout << "NEWTON ERROR = " << newtonError_ << endl;
	  cout << "LAGRANGE MULTIPLIERS\n";
	  for (int i = 0; i < this->dim(); i++)
	    cout << i + 1 << " " << newtonLambda_(i) << endl;
	  if ( (this->compute() == 1) || (this->compute() == 2) )
	  {
	    cout << "MAXENT BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	      cout << i + 1 << " " << this->phi(i) << endl;
	  }
	  if (this->compute() == 2)
	  {
	    cout << "GRADIENT OF MAXENT BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	    {
	      cout << i + 1 << " ";
		    for (int j = 0; j < this->dim(); j++)
		      cout << this->phiDer(i,j) << " ";
		    cout << endl;
	    }
	  }
	  cout << endl;
	  cout.unsetf(ios::scientific);
	  // print out to output file
	  ofstream outFile; 
    outFile.open("meshfreeresults.txt", ios::app);
	  outFile << "*****************************************************\n";
	  outFile << "************ MAXENT COMPUTATION SUMMARY *************\n";
	  outFile << "*****************************************************\n";
	  outFile.setf(ios::fixed);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "EVALUATION POINT: " << this->xSample() << endl;
	  outFile.unsetf(ios::fixed);
	  outFile << "PRIOR FUNCTION: " << weightName_ << endl;
    outFile << "NODE SPACING: " << this->nodeSpacing() << endl;
	  outFile << "GAMMA: " << this->gamma() << endl;
	  outFile << "CONVERGENCE ATTAINED IN " << newtonIter_ <<" ITERATIONS\n";
	  outFile.setf(ios::scientific);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "REQUIRED TOLERANCE = " << rtol_ << endl;
	  outFile << "NEWTON ERROR = " << newtonError_ << endl;
	  outFile << "LAGRANGE MULTIPLIERS\n";
	  for (int i = 0; i < this->dim(); i++)
	    outFile << i + 1 << " " << newtonLambda_(i) << endl;
	  if ( (this->compute() == 1) || (this->compute() == 2) )
	  {
	    outFile << "MAXENT BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	      outFile << i + 1 << " " << this->phi(i) << endl;
	  }
	  if (this->compute() == 2)
	  {
	    outFile << "GRADIENT OF MAXENT BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	    {
	      outFile << i + 1 << " ";
		    for (int j = 0; j < this->dim(); j++)
		      outFile << this->phiDer(i,j) << " ";
		    outFile << endl;
	    }
	  }
	  outFile << endl;
	  outFile.close();
	  // run consistency check if required
    if (forceConsistencyCheck_)
      consistencyCheck(); 
  }
  else if (failure_)
  {
	  // print out on the screen
	  cout << "*****************************************************\n";
	  cout << "************ MAXENT COMPUTATION SUMMARY *************\n";
	  cout << "*****************************************************\n";
	  cout.setf(ios::fixed);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "EVALUATION POINT: " << this->xSample() << endl;
    cout << "APPROX. ORDER: " << this->order() << endl;
	  cout.unsetf(ios::fixed);
	  cout << "PRIOR FUNCTION: " << weightName_ << endl;
    cout << "NODE SPACING: " << this->nodeSpacing() << endl;
	  cout << "GAMMA: " << this->gamma() << endl;
	  cout << "<<< FAILED >>>\n";
	  cout << "CONVERGENCE NOT ATTAINED IN " << maxIter_ <<" ITERATIONS\n";
	  cout.unsetf(ios::fixed);
	  cout.setf(ios::scientific);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "REQUIRED TOLERANCE = " << rtol_ << endl;
	  cout << "NEWTON ERROR = " << newtonError_ << endl;
	  cout.unsetf(ios::scientific);
	  //print to an output file
	  ofstream outFile; 
    outFile.open("meshfreeresults.txt", ios::app);
	  outFile << "*****************************************************\n";
	  outFile << "************ MAXENT COMPUTATION SUMMARY *************\n";
	  outFile << "*****************************************************\n";
	  outFile.setf(ios::fixed);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "EVALUATION POINT: " << this->xSample() << endl;
    outFile << "APPROX. ORDER: " << this->order() << endl;
	  outFile.unsetf(ios::fixed);
	  outFile << "PRIOR FUNCTION: " << weightName_ << endl;
    outFile << "NODE SPACING: " << this->nodeSpacing() << endl;
	  outFile << "GAMMA: " << this->gamma() << endl;
	  outFile << "<<< FAILED >>>\n";
	  outFile << "CONVERGENCE NOT ATTAINED IN " << maxIter_ <<" ITERATIONS\n";
	  outFile.unsetf(ios::fixed);
	  outFile.setf(ios::scientific);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "REQUIRED TOLERANCE = " << rtol_ << endl;
	  outFile << "NEWTON ERROR = " << newtonError_ << endl;
	  outFile.close();
	  // run consistency check in the base class
    consistencyCheck();
  }
}

/*******************************************************************************
* FUNCTION consistencyCheck                                                    *
* Purpose                                                                      *
* =======                                                                      *
* Check if phi and phiDer were correctly computed. (Overrride base class       * 
* function)                                                                    *
*******************************************************************************/
//
void
Maxent::
consistencyCheck() const
{	
  double tol = 5.0 * rtol_;
  int dim = this->dim();
  int order = this->order();
  int compute = this->compute();
  Vec<double> phi = this->phi();
  Mat<double> phiDer =  this->phiDer();
  // contributing xShift matrix
  Mat<double> xs = xShiftContribute();
  // print out on the screen
  cout << "*****************************************************\n";
  cout << "***************** CONSISTENCY CHECK *****************\n";
  cout << "*****************************************************\n";
  cout.setf(ios::scientific);
  cout.setf(ios::showpoint);
  cout.precision(6);
  // partition of unity consistency
  if (abs(phi.sum() - 1.0) > tol)
  {
    cout << "WARNING: PU consistency error: " << endl;
    cout << "abs( Sum_i=1^n{phi_i} - 1 ) = " << abs(phi.sum() - 1.0) << endl;
  }
  else
  {
    cout << "PU consistency check OK." << endl;
  }
  // approx. and derivative consistency check
  if (order == 1)
  {
    // approx. order consistency check
    Vec<double> approxCoord = phi * xs;
    if (approxCoord.norm() > tol)
    {
      cout << "WARNING: Linear consistency error: " << endl;
      cout << "norm[ Sum_i=1^n{phi_i*(x_i-x) ] = " << approxCoord.norm() << endl;
    }
    else
    {
      cout << "Linear consistency check OK." << endl;
    }
    if (compute == 2)
    {
      // derivative constant consistency check
      Vec<double> sumDer(dim);
      for (int i = 0; i < dim; i++)
        sumDer(i) = phiDer.sumCol(i+1);
      if (sumDer.norm() > tol)
      {
        cout << "WARNING: Derivative constant consistency error: " << endl;
        cout << "norm[ Sum_i=1^n{Grad(phi_i)} ] = " << sumDer.norm() << endl;
      }
      else
      {
        cout << "Derivative constant consistency check OK." << endl;
      }
      // derivative linear consistency check
      Vec<double> auxVec(dim * dim);
      int k = 0;
      for (int i = 0; i < dim; i++)
      {
        for (int j = 0; j < dim; j++)
        {
          auxVec(k) = phiDer.getCol(i+1) * xs.getCol(j+1);
          if (i == j) auxVec(k) -= 1.0;
            k++;
        }
      }
      if (auxVec.norm() > tol)
      {
        cout << "WARNING: Derivative linear consistency error: " << endl;
        cout << "norm[ Sum_i=1^n{Grad(phi_i)(X)(x_i - x)} ] = " << auxVec.norm() << endl;
      }
      else
      {
        cout << "Derivative linear consistency check OK." << endl;
      }
    }
    cout << endl;
    cout.unsetf(ios::scientific);
  }
  else 
  {
    cout << "ERROR: Approximation order greater than 1 is not available for ";
    cout << "maxent basis functions" << endl;
    exit(1);
  }

  // print out to output file
  ofstream outFile;
  outFile.open("meshfreeresults.txt", ios::app);
  outFile << "*****************************************************\n";
  outFile << "***************** CONSISTENCY CHECK *****************\n";
  outFile << "*****************************************************\n";
  outFile.setf(ios::scientific);
  outFile.setf(ios::showpoint);
  outFile.precision(6);
  // partition of unity consistency
  if (abs(phi.sum() - 1.0) > tol)
  {
    outFile << "WARNING: PU consistency error: " << endl;
    outFile << "abs( Sum_i=1^n{phi_i} - 1 ) = " << abs(phi.sum() - 1.0) << endl;
  }
  else
  {
    outFile << "PU consistency check OK." << endl;
  }
  // approx. and derivative consistency check
  if (order == 1)
  {
    // approx. order consistency check
    Vec<double> approxCoord = phi * xs;
    if (approxCoord.norm() > tol)
    {
      outFile << "WARNING: Linear consistency error: " << endl;
      outFile << "norm[ Sum_i=1^n{phi_i*(x_i-x) ] = " << approxCoord.norm() << endl;
    }
    else
    {
      outFile << "Linear consistency check OK." << endl;
    }
    if (compute == 2)
    {
      // derivative constant consistency check
      Vec<double> sumDer(dim);
      for (int i = 0; i < dim; i++)
        sumDer(i) = phiDer.sumCol(i+1);
      if (sumDer.norm() > tol)
      {
        outFile << "WARNING: Derivative constant consistency error: " << endl;
        outFile << "norm[ Sum_i=1^n{Grad(phi_i)} ] = " << sumDer.norm() << endl;
      }
      else
      {
        outFile << "Derivative constant consistency check OK." << endl;
      }
      // derivative linear consistency check
      Vec<double> auxVec(dim * dim);
      int k = 0;
      for (int i = 0; i < dim; i++)
      {
        for (int j = 0; j < dim; j++)
        {
          auxVec(k) = phiDer.getCol(i+1) * xs.getCol(j+1);
          if (i == j) auxVec(k) -= 1.0;
          k++;
        }
      }
      if (auxVec.norm() > tol)
      {
        outFile << "WARNING: Derivative linear consistency error: " << endl;
        outFile << "norm[ Sum_i=1^n{Grad(phi_i)(X)(x_i - x)} ] = " << auxVec.norm() << endl;
      }
      else
      {
        outFile << "Derivative linear consistency check OK." << endl;
      }
    }
    outFile << endl;
  }
  else // code here for order > 1 
  {
    outFile << "ERROR: Approximation order greater than 1 is not available for ";
    outFile << "maxent basis functions" << endl;
    exit(1);
  }
  // close output file
  outFile.close(); 
}

/*******************************************************************************
*                                                                              *
*                            MLS CLASS IMPLEMENTATION                          *
*                            ========================                          *
*                                                                              *
*******************************************************************************/

// constructors 
Mls::
Mls(int dim, 
    int nNodes, 
    const Mat<double>& nodeCoord,
    const Vec<double>& xSample, 
    const Vec<double>& nodeSpacing,
    const string& weightName, 
    double gamma, 
    int order, 
    int compute,
    bool autoIncreaseSupportSize, 
    bool forceConsistencyCheck,
    bool variousSamplePoints, 
    bool printAllResults)
: MeshFree("mls",dim,nNodes,nodeCoord,xSample,nodeSpacing,gamma,
           order,compute,autoIncreaseSupportSize,variousSamplePoints)
{
  // initialize some private variables
  weightName_ = weightName;
  failure_ = 0;
  forceConsistencyCheck_ = forceConsistencyCheck;
  printAllResults_ = printAllResults;
  // do some checks
  if (dim > 3)
  {
    cout << "ERROR: Problem dimension greater than 3 is not available" << endl;
    cout << endl;
    ofstream outFile;
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Problem dimension greater than 3 is not available" << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if (order > 1)
  {
    cout << "ERROR: Approximation order greater than 1 is not available for ";
    cout << "mls basis functions" << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Approximation order greater than 1 is not available for ";
    outFile << "mls basis functions" << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ( (compute != 1) && (compute != 2))
  {
    cout << "ERROR: variable ''compute'' must be either 1 or 2." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: variable ''compute'' must be either 1 or 2." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)nodeCoord.cols() != dim)
  {
    cout << "ERROR: Dimension of nodal coordinates does not "; 
    cout << "coincide with problem dimension." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Dimension of nodal coordinates does not "; 
    outFile << "coincide with problem dimension." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)nodeCoord.rows() != nNodes)
  {
    cout << "ERROR: Number of nodes does not "; 
    cout << "coincide with number of rows of coordinate matrix." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Number of nodes does not "; 
    outFile << "coincide with number of rows of coordinate matrix." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if ((int)xSample.size() != dim)
  {
    cout << "ERROR: Dimension of sample point does not "; 
    cout << "coincide with problem dimension." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: Dimension of sample point does not "; 
    outFile << "coincide with problem dimension." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
  if (forceConsistencyCheck && (!printAllResults))
  {
    cout << "printAllResults was changed to TRUE "; 
    cout << "in order to force consistency check." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "printAllResults was changed to TRUE "; 
    outFile << "in order to force consistency check." << endl;
    outFile << endl;
    outFile.close();
    // change value
    printAllResults_ = 1;
  }
}

Mls::
Mls(const Mls& rhsObj)
: MeshFree(rhsObj)
{
  weightName_ = rhsObj.weightName_;
  failure_ = rhsObj.failure_;
  forceConsistencyCheck_ = rhsObj.forceConsistencyCheck_;
  printAllResults_ = rhsObj.printAllResults_;
}

// assignement operator
const Mls& 
Mls::
operator=(const Mls& rhsObj)
{
  weightName_ = rhsObj.weightName_;
  failure_ = rhsObj.failure_;
  forceConsistencyCheck_ = rhsObj.forceConsistencyCheck_;
  printAllResults_ = rhsObj.printAllResults_;
  return *this;
}

// destructor
Mls::~Mls()
{
}

// define class functions

/*******************************************************************************
* FUNCTION computeMeshfree                                                     *
* Purpose                                                                      *
* =======                                                                      *
* Drive and manage the entire mls computation.                                 *
*******************************************************************************/
//
void
Mls::
computeMeshfree()
{  
  // compute weight function
  computeWeight();
  // compute polynomial matrices and related to use in mls computation
  int dim = this->dim();
  int order = this->order();
  int length = this->length();
  int polyBasisLength;
  if (dim == 1)
    polyBasisLength = order + 1;
  else if (dim == 2)
    polyBasisLength = (order + 1) * (order + 2) / 2;
  else if (dim == 3)
    polyBasisLength = (order + 1) * (order + 2) * (order + 3) / 6;  
  Mat<double> bm(polyBasisLength,length);                     // polynomial-weighted matrix (B)
  Mat<double> bmDer(polyBasisLength,dim*length);              // derivatives of B
  Mat<double> am(polyBasisLength,polyBasisLength,0.0);        // moment matrix (A)
  Mat<double> amDer(polyBasisLength,dim*polyBasisLength,0.0); // derivatives of A
  Vec<double> gv(polyBasisLength);                            // solution of: A*gv=basis_vector
  computeMatrices(bm,bmDer,am,amDer,gv,polyBasisLength);
  // compute basis function and its gradient
  if (this->compute() == 1)
  {
    Vec<double> phi(this->length());
    computePhi(phi,gv,bm);
    this->setPhi(phi);
  }
  else if (this->compute() == 2)
  {
    Vec<double> phi(this->length());
    computePhi(phi,gv,bm);
    Mat<double> phiDer(this->length(),this->dim());
    computePhiDer(am,amDer,bm,bmDer,gv,polyBasisLength,phiDer);
    this->setPhi(phi);
    this->setPhiDer(phiDer);
  }
  // print maxent results
  printResults();
}

/*******************************************************************************
* FUNCTION computeWeight                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Compute weight function and find the neighbors (contributing nodes at eval.  *
* point)                                                                       *
*******************************************************************************/
//
void
Mls::
computeWeight()
{
  // will compute and set weightFun_, weightFunDer_, contribute_ and length_
  // and shifted coordinates in the base class private variables
  if (weightName_ == "gaussian")
  {
    double tol_0 = 1e-8;
    this->gaussian(tol_0);
  }
  else if (weightName_ == "cubic")
    this->cubicSpline();
  else if (weightName_ == "quartic")
    this->quarticSpline();
  else if (weightName_ == "constant")
    this->constantWeight();
  else
  {
    cout << "ERROR: " << weightName_;
    cout << " weight (kernel) function is not available." << endl;
    cout << endl;
    ofstream outFile; 
    outFile.open("messages.txt", ios::app);
    outFile << "ERROR: " << weightName_;
    outFile << " weight (kernel) function is not available." << endl;
    outFile << endl;
    outFile.close();
    exit(1);
  }
}

/*******************************************************************************
* FUNCTION computeMatrices                                                     *
* Purpose                                                                      *
* =======                                                                      *
* Compute some matrices to be used in phi and phiDer computation               *
*******************************************************************************/
//
void
Mls::
computeMatrices(Mat<double>& bm,
                Mat<double>& bmDer,
                Mat<double>& am,
                Mat<double>& amDer,
                Vec<double>& gv,
                int polyBasisLength)
{
  failure_ = 0;
  int dim = this->dim();
  int length = this->length();
  int order = this->order();
  // get nodal coordinates from base class
  Mat<double> xs = this->nodeCoordContribute();
  // polynomial base matrix (P=pm), polynomial-weighted matrix (B=bm), 
  // derivatives of polynomial-weighted matrix (B,x=bmDer), 
  // moment matrix (A=am) and derivative of moment matrix (A,x=amDer)  
  Mat<double> pm(length,polyBasisLength);
  if (order == 1)
  {
    for (int i = 0; i < length; i++)
    {
      pm(i,0) = 1.0;
      bm(0,i) = this->weightFun(i);
      for (int j = 1; j < polyBasisLength; j++)
      {
        pm(i,j) = xs(i,j-1);
        bm(j,i) = (this->weightFun(i)) * pm(i,j);
      }
      for (int j = 0; j < polyBasisLength; j++)
        for (int r = 0; r < polyBasisLength; r++)
          am(j,r) += (this->weightFun(i)) * pm(i,j) * pm(i,r);
      if (this->compute() == 2) // if basis functions derivatives are required
      {
        for (int j = 0; j < polyBasisLength; j++)
        {
          for (int k = 0; k < dim; k++)
          {
            bmDer(j,i+k*length) = (this->weightFunDer(i,k)) * pm(i,j);
            for (int r = 0; r < polyBasisLength; r++)
              amDer(j,r+k*polyBasisLength) += this->weightFunDer(i,k) * pm(i,j) * pm(i,r);
          }
        }
      }
    }
    // basis vector
    Vec<double> pv(polyBasisLength,0.0);
    pv(0) = 1.0;
    for (int i = 1; i < polyBasisLength; i++)
      pv(i) = this->xSample(i-1);
    // solve the linear system: am * gv = pv
    int stat = 0;
    gv = symmDenseLinearSolver(am,pv,&stat);
    if (stat != 0) 
    {
      cout << "In mls computation." << endl;
      cout << "EVALUATION POINT: " << this->xSample() << endl;
      cout << "ERROR: moment matrix is singular.";
      cout << " Possibly more neighbors are needed." << endl; 
      cout << endl;
      ofstream outFile; 
      outFile.open("messages.txt", ios::app);
      outFile << "In mls computation." << endl;
      outFile << "EVALUATION POINT: " << this->xSample() << endl;
      outFile << "ERROR: moment matrix is singular.";
      outFile << " Possibly more neighbors are needed." << endl; 
      outFile << endl;
      outFile.close();
      exit(1);
    }
  }
  else if (order == 2)
  {
    // code here
  }
}

/*******************************************************************************
* FUNCTION computePhi                                                          *
* Purpose                                                                      *
* =======                                                                      *
* Compute mls basis functions                                                  *
*******************************************************************************/
//
void
Mls::
computePhi(Vec<double>& phi,
           const Vec<double>& gv,
           const Mat<double>& bm) const
{
  phi = gv * bm;
}

/*******************************************************************************
* FUNCTION computePhiDer                                                       *
* Purpose                                                                      *
* =======                                                                      *
* Compute the gradient of mls basis functions. An example in 2D is:            *
* phiDer = [ ... ... ; der_x  der_y; ... ...]                                  *
*******************************************************************************/
//
void
Mls::
computePhiDer(const Mat<double>& am,
              const Mat<double>& amDer,
              const Mat<double>& bm,
              const Mat<double>& bmDer,
              const Vec<double>& gv,
              int polyBasisLength,
              Mat<double>& phiDer) const
{
  int dim = this->dim();
  int length = this->length();
  int order = this->order();
  if (order == 1)
  {
    // gradient of basis vector
    Mat<double> pvDer(polyBasisLength,dim,0.0); 
    for (int j = 0; j < dim; j++)
      pvDer(dim-j,dim-j-1) = 1.0;
    // to store a column of pvDer
    Vec<double> pvDer_c(polyBasisLength); 
    // compute gradient of basis functions
    Vec<double> gvDer(polyBasisLength);
    for (int i = 0; i < dim; i++)
    {
      for (int j = 0; j < polyBasisLength; j++)
        for (int k = 0; k < polyBasisLength; k++)
          pvDer(j,i) -= amDer(j,k+i*polyBasisLength) * gv(k);
      pvDer_c = pvDer.getCol(i+1);
      int stat = 0;
      gvDer = symmDenseLinearSolver(am,pvDer_c,&stat);
      if (stat != 0) 
      {
        cout << "In mls computation." << endl;
        cout << "EVALUATION POINT: " << this->xSample() << endl;
        cout << "ERROR: moment matrix is singular.";
        cout << " Possibly more neighbors are needed." << endl; 
        cout << endl;
        ofstream outFile; 
        outFile.open("messages.txt", ios::app);
        outFile << "In mls computation." << endl;
        outFile << "EVALUATION POINT: " << this->xSample() << endl;
        outFile << "ERROR: moment matrix is singular.";
        outFile << " Possibly more neighbors are needed." << endl; 
        outFile << endl;
        outFile.close();
        exit(1);
      }
      for (int k = 0; k < length; k++)
        for (int j = 0; j < polyBasisLength; j++)
          phiDer(k,i) += gvDer(j) * bm(j,k) + gv(j) * bmDer(j,k+i*length);
    }
  }
  else if (order == 2)
  {
    // code here
  }
}

/*******************************************************************************
* FUNCTION printResults                                                     *
* Purpose                                                                      *
* =======                                                                      *
* Print a summary of mls computations                                          *
*******************************************************************************/
//
void
Mls::
printResults()
{
  if ( (!failure_) && printAllResults_)
  { 
	  // print out on the screen
	  cout << "*****************************************************\n";
	  cout << "************** MLS COMPUTATION SUMMARY **************\n";
	  cout << "*****************************************************\n";
	  cout.setf(ios::fixed);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "EVALUATION POINT: " << this->xSample() << endl;
    cout << "APPROX. ORDER: " << this->order() << endl;
	  cout.unsetf(ios::fixed);
	  cout << "WEIGHT (KERNEL) FUNCTION: " << weightName_ << endl;
    cout << "NODE SPACING: " << this->nodeSpacing() << endl;
	  cout << "GAMMA: " << this->gamma() << endl;
	  cout.setf(ios::scientific);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  if ( (this->compute() == 1) || (this->compute() == 2) )
	  {
	    cout << "MLS BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	      cout << i + 1 << " " << this->phi(i) << endl;
	  }
	  if (this->compute() == 2)
	  {
	    cout << "GRADIENT OF MLS BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	    {
	      cout << i + 1 << " ";
		    for (int j = 0; j < this->dim(); j++)
		      cout << this->phiDer(i,j) << " ";
		    cout << endl;
	    }
	  }
	  cout << endl;
	  cout.unsetf(ios::scientific);
	  // print out to output file
	  ofstream outFile; 
    outFile.open("meshfreeresults.txt", ios::app);
	  outFile << "*****************************************************\n";
	  outFile << "************** MLS COMPUTATION SUMMARY **************\n";
	  outFile << "*****************************************************\n";
	  outFile.setf(ios::fixed);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "EVALUATION POINT: " << this->xSample() << endl;
    outFile << "APPROX. ORDER: " << this->order() << endl;
	  outFile.unsetf(ios::fixed);
	  outFile << "WEIGHT (KERNEL) FUNCTION: " << weightName_ << endl;
    outFile << "NODE SPACING: " << this->nodeSpacing() << endl;
	  outFile << "GAMMA: " << this->gamma() << endl;
	  outFile.setf(ios::scientific);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  if ( (this->compute() == 1) || (this->compute() == 2) )
	  {
	    outFile << "MLS BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	      outFile << i + 1 << " " << this->phi(i) << endl;
	  }
	  if (this->compute() == 2)
	  {
	    outFile << "GRADIENT OF MLS BASIS FUNCTIONS:\n";
	    for (int i = 0; i < this->length(); i++)
	    {
	      outFile << i + 1 << " ";
		    for (int j = 0; j < this->dim(); j++)
		      outFile << this->phiDer(i,j) << " ";
		    outFile << endl;
	    }
	  }
	  outFile << endl;
	  outFile.close();
	  // run consistency check if required
    if (forceConsistencyCheck_)
      consistencyCheck(); 
  }
  else if (failure_)
  {
	  // print out on the screen
	  cout << "*****************************************************\n";
	  cout << "************** MLS COMPUTATION SUMMARY **************\n";
	  cout << "*****************************************************\n";
	  cout.setf(ios::fixed);
	  cout.setf(ios::showpoint);
	  cout.precision(6);
	  cout << "EVALUATION POINT: " << this->xSample() << endl;
    cout << "APPROX. ORDER: " << this->order() << endl;
	  cout.unsetf(ios::fixed);
	  cout << "WEIGHT (KERNEL) FUNCTION: " << weightName_ << endl;
    cout << "NODE SPACING: " << this->nodeSpacing() << endl;
	  cout << "GAMMA: " << this->gamma() << endl;
	  cout << "<<< FAILED >>>\n";
	  //print to an output file
	  ofstream outFile; 
    outFile.open("meshfreeresults.txt", ios::app);
	  outFile << "*****************************************************\n";
	  outFile<< "************** MLS COMPUTATION SUMMARY ***************\n";
	  outFile << "*****************************************************\n";
	  outFile.setf(ios::fixed);
	  outFile.setf(ios::showpoint);
	  outFile.precision(6);
	  outFile << "EVALUATION POINT: " << this->xSample() << endl;
    outFile << "APPROX. ORDER: " << this->order() << endl;
	  outFile.unsetf(ios::fixed);
	  outFile << "WEIGHT (KERNEL) FUNCTION: " << weightName_ << endl;
    outFile << "NODE SPACING: " << this->nodeSpacing() << endl;
	  outFile << "GAMMA: " << this->gamma() << endl;
	  outFile << "<<< FAILED >>>\n";
	  outFile.close();
	  // run consistency check 
    consistencyCheck();
  }
}
