% function time=assembly1(xmin,xmax,ymin,ymax,divx,divy)
%
% Purpose
% =======                                                                      
% Assembly global stiffness matrix of the 2D heat conduction problem on the 
% domain (xmin,xmax)x(ymin,ymax) of unit thickness. Dx=Dy=1 is assumed.
%
% Assembly method:  K(i,j) = K(i,j) + number, with K a sparse matrix
%
% Variables
% =========
% xmin   : x-coordinate minimum value
% xmax   : x-coordinate maximum value
% ymin   : y-coordinate minimum value
% ymax   : y-coordinate maximum value
% divx   : number of divisions along x-direction
% divy   : number of divisions along y-direction
%
% Return
% ======
% time   : elapsed time of stiffness matrix assembly
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function time=assembly1(xmin,xmax,ymin,ymax,divx,divy)

% create uniform mesh of 3-node triangles
[ncoord,connect]=meshT3u(xmin,xmax,ymin,ymax,divx,divy);

numel=size(connect,1);         % number of elements
numnod=size(ncoord,1);         % number of nodes

% assembly
tic
K=sparse(numnod,numnod);
for e=1:numel % loop over elements
  nodes=connect(e,:).'; 
  xy=ncoord(nodes,:);
  [x,w]=gausspoints(xy);
  for g=1:3 % loop over gauss points (3 per element: see gausspoints.m)  
    [phi,phider]=shapefunctionsT3(xy,x(g,:));
    K(nodes,nodes)=K(nodes,nodes)+...
                   phider(:,1)*(phider(:,1).')*w(g)+...
                   phider(:,2)*(phider(:,2).')*w(g);  
  end
end
time=toc;





    
    
    







