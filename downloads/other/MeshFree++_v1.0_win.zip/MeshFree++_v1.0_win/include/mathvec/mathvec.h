/*******************************************************************************
*                MathVec++: A MATRIX-VECTOR C++ TEMPLATE                       *
*                =======================================                       *
*                                                                              *
*  Created by  : Alejandro A. Ortiz                                            *
*  E-mail      : alortiz@ucdavis.edu                                           *
*  Version     : 1.0                                                           *
*  Date        : September 23, 2009                                            *
*                                                                              *
*                         Copyright and License                                *
*                         =====================                                *
*                                                                              *
*                   MathVec++ 1.0, Copyright (c) 2009                          *
*                         by Alejandro A. Ortiz,                               *
*                          alortiz@ucdavis.edu                                 *
*             Department of Civil & Environmental Engineering,                 *
*             University of California, Davis, CA 95616, U.S.A.                *
*                          All Rights Reserved.                                *
*                                                                              *
*    Your use or distribution of MathVec++ template or any derivative code     *
*    implies that you agree to this License.                                   *
*                                                                              *
*    This program is distributed in the hope that it will be useful,           *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. This program is      *
*    free software and you can choose any of the following license terms:      *
*                                                                              *
*    1) GNU General Public License as published by the Free Software           *
*       Foundation; either version 3 of the License, or(at your option) any    *
*       later version. For details see copy of GPL in folder License\gnu of    *
*       this distribution.                                                     *
*                                                                              *
*    2) GNU Lesser General Public License as published by the Free Software    *
*       Foundation; either version 3 of the License, or(at your option) any    *
*       later version. For details see copy of LGPL in folder License\gnu      *
*       of this distribution.                                                  *
*                                                                              *
*    3) Alternatively, you may choose to comply with the following             * 
*       UMFPACK-style license:                                                 *
*                                                                              *
*       THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY           *
*       EXPRESSED OR IMPLIED. ANY USE IS AT YOUR OWN RISK.                     *
*                                                                              *
*       Permission is hereby granted to use or copy this program, provided     * 
*       that the Copyright, this License, and the Availability of the          * 
*       original version is retained on all copies. User documentation of      *
*       any code that uses this code or any derivative code must cite the      * 
*       Copyright, this License, the Availability note, and "Used by           *
*       permission". Permission to modify the code and to distribute           * 
*       modified code is granted, provided the Copyright, this License,        * 
*       and the Availability note are retained, and a notice that the code     * 
*       was modified is included. This software is provided to you free of     * 
*       charge.                                                                *    
*                                                                              *
*    MathVec++ uses TAUCS, A library of Sparse Linear Solvers by permission    *
*    of Sivian Toledo. You must comply with TAUCS license terms. For details   *
*    see folder libs/taucs of this distribution.                               * 
*                                                                              *
*******************************************************************************/

#ifndef MATHVEC_H
#define MATHVEC_H

#include <iostream>
#include <vector>
#include <cmath>
#include <limits>
#include <algorithm>
using namespace std;  

#define TAUCS_CORE_DOUBLE
#include "taucs.h"

/******************************************************************************
*                             FORWARD DECLARATIONS                            *
******************************************************************************/

// forward declaration of "Vec class" to use in 
// 1) forward dec. of "ostream" to be used in "Vec class"
// 2) use objects of "Vec class" in "Mat class"
template <class T>
class Vec; 

// forward declaration of "ostream" to use in "Vec class"
template <class T> 
ostream& operator<<(ostream&, const Vec<T>&);

// forward declaration of "Mat class" to use objects of this class
// in "Vec class"
template <class T>
class Mat; 

// forward declaration of "ostream" to use in "Mat class"
template <class T> 
ostream& operator<<(ostream&, const Mat<T>&);

/******************************************************************************
*                                VECTOR CLASS: Vec                            *
******************************************************************************/

// class definition
template <class T>
class Vec
{
public:
  Vec();
  Vec(int length); 
  Vec(int length, T typeValue); 
  Vec(const Vec<T>& rhsObj); 
  const Vec<T>& operator=(const Vec<T>& rhsObj);
  const Vec<T>& operator=(T typeVal);
  const Vec<T>& operator+=(const Vec<T>& obj2);
  const Vec<T>& operator-=(const Vec<T>& obj2);
  const Vec<T>& operator*=(T typeVal);
  const Vec<T>& operator/=(T typeVal);
  const Vec<T> operator+(const Vec<T>& obj2) const;
  const Vec<T> operator-(const Vec<T>& obj2) const;
  const Vec<T> operator*(T typeVal) const;
  const Vec<T> operator*(const Mat<T>& obj2) const;
  const Vec<T> operator/(T typeVal) const;
  const Vec<T> operator-() const;
  T operator*(const Vec<T>& obj2) const;
  const T& operator()(int index) const;
  T& operator()(int index);
  typename vector<T>::const_iterator begin() const;
  typename vector<T>::const_iterator end() const;
  void setMyVec(const vector<T>& obj) const;
  const vector<T> getMyVec() const;
  unsigned size() const;
  void push_back(T typeVal);
  void resize(int size);
  void clear();
  const Vec<T>& makeNull();
  const Vec<T>& makeUnit();
  T norm() const;
  T sum() const;
  T max() const;
  T min() const;
  friend ostream& operator<< <T>(ostream& outputStream, const Vec<T>& obj);
  ~Vec();
private:
  vector<T> myVec_;
};

// constructors
template<class T> 
Vec<T>::
Vec()
{
}

template<class T> 
Vec<T>::
Vec(int length)
{
  myVec_ = vector<T>(length);
}

template<class T> 
Vec<T>::
Vec(int length, T typeVal)
{
  myVec_ = vector<T>(length,typeVal);
}

template<class T> 
Vec<T>::
Vec(const Vec<T>& rhsObj) 
{
  myVec_ = rhsObj.myVec_;
}

// destructor
template<class T> 
Vec<T>::
~Vec()
{
}

// assignment operators
template<class T> 
const Vec<T>& 
Vec<T>::
operator=(const Vec<T>& rhsObj)
{
  myVec_ = rhsObj.myVec_;
  return *this;
}

template<class T> 
const Vec<T>& 
Vec<T>::
operator=(T typeVal)
{
  for (unsigned i = 0; i < this->size(); i++)
    (*this)(i) = typeVal;
  return *this;
}

// adding a vector to the current vector
template <class T>
const Vec<T>& 
Vec<T>::
operator+=(const Vec<T>& obj2)
{
  if (this->size() != obj2.size())
  {
    cout << "ERROR: can't add 2 vectors of different size.\n";
		exit(1);
  }
  for (unsigned i = 0; i < obj2.size(); i++)
    (*this)(i) += obj2(i);
  return *this;
}

// subtracting a vector from the current vector
template<class T>
const Vec<T>&
Vec<T>::
operator-=(const Vec<T>& obj2)
{
  if (this->size() != obj2.size())
  {
    cout << "ERROR: can't subtract 2 vectors of different size.\n";
		exit(1);
  }
  for (unsigned i = 0; i < obj2.size(); i++)
    (*this)(i) -= obj2(i);
  return *this;
} 

// multiplying the current vector by a scalar
template<class T>
const Vec<T>&
Vec<T>::
operator*=(T typeVal)
{  
  for (unsigned i = 0; i < this->size(); i++)
  {
    (*this)(i) *= typeVal; 
  }
  return *this;
} 

// dividing the current vector by a scalar
template<class T>
const Vec<T>&
Vec<T>::
operator/=(T typeVal)
{  
  for (unsigned i = 0; i < this->size(); i++)
  {
    (*this)(i) /= typeVal; 
  }
  return *this;
} 

// vector3 = vector1 + vector2
template<class T>
const Vec<T>
Vec<T>::
operator+(const Vec<T>& obj2) const
{
  if (this->size() != obj2.size())
  {
    cout << "ERROR: can't add 2 vectors of different size.\n";
		exit(1);
  }
  return (Vec<T>(*this) += obj2);
} 

// vector3 = vector1 - vector2
template<class T>
const Vec<T>
Vec<T>::
operator-(const Vec<T>& obj2) const
{
  if (this->size() != obj2.size())
  {
    cout << "ERROR: can't sustract 2 vectors of different size.\n";
		exit(1);
  }
  return (Vec<T>(*this) -= obj2);
} 

// vector2 = vector1 * scalar
template<class T>
const Vec<T>
Vec<T>::
operator*(T typeVal) const
{
  return (Vec<T>(*this) *= typeVal);
} 

// vector2 = vector1 * matrix
// obs.: vector 1 need not to be transposed
template<class T> 
const Vec<T> 
Vec<T>::
operator*(const Mat<T>& obj2) const
{
  bool isTrue = this->size() != obj2.rows();
  if (isTrue)
  {
    cout << "ERROR: can't multiply a vector by a matrix of different inner dimension.\n";
		exit(1);
  }
  Vec<T> temp(obj2.cols());
  for (unsigned i = 0; i < obj2.cols(); i++)
  {
    T sum = 0;
    for (unsigned j = 0; j < obj2.rows(); j++)
    {
      sum += (*this)(j) * obj2(j,i);
    }
    temp(i) = sum;
  }
  return temp;
}

// vector2 = vector1/scalar
template<class T>
const Vec<T>
Vec<T>::
operator/(T typeVal) const
{
  return (Vec<T>(*this) /= typeVal);
} 

// overloading unary operator: the negative of ...
template<class T>
const Vec<T>
Vec<T>::
operator-() const
{
  return (Vec<T>(*this) * (-1));
}

// scalar = vector1 * vector2 (inner product)
template<class T>
T
Vec<T>::
operator*(const Vec<T>& obj2) const
{
  if (this->size() != obj2.size())
  {
    cout << "ERROR: can't multiply 2 vectors of different size.\n";
		exit(1);
  }
  T temp = 0;
  for (unsigned i = 0; i < obj2.size(); i++)
    temp += (*this)(i) * obj2(i);
  return temp;
}

// overload () only to read. changes are not allowed due to "const" 
// after the function prototype
template<class T>
const T&
Vec<T>::
operator()(int index) const
{
  return myVec_.at(index);
} 

// overload () to read and/or change values by reference
template<class T>
T&
Vec<T>::
operator()(int index)
{
  return myVec_[index];
}

// overload begin() from vector class
template<class T>
typename vector<T>::const_iterator
Vec<T>::
begin() const
{
  return myVec_.begin();
}

// overload end() from vector class
template<class T>
typename vector<T>::const_iterator
Vec<T>::
end() const
{
  return myVec_.end();
}

// directly set myVec_ with an object of std::vector
template<class T>
void 
Vec<T>::
setMyVec(const vector<T>& obj) const
{
  myVec_ = obj;
}

// get a copy of the private variable myVec_
template<class T>
const vector<T>
Vec<T>::
getMyVec() const
{
  return myVec_;
}

// get the size of the vector
template<class T> 
unsigned
Vec<T>::
size() const
{
  return (myVec_.size());
}

// push a number to the first available empty cell
template<class T> 
void
Vec<T>::
push_back(T typeVal)
{
  myVec_.push_back(typeVal);
}

// wrapper for std::vector resize() function
template<class T> 
void
Vec<T>::
resize(int size)
{
  myVec_.resize(size);
}

// wrapper for std::vector clear() function.
// remove all elements from the vector
template<class T> 
void
Vec<T>::
clear()
{
  myVec_.clear();
}

// transform the current vector to null vector
template<class T> 
const Vec<T>& 
Vec<T>::
makeNull()
{
  return ((*this) = 0);
}

// transform the current vector to unit vector
template<class T> 
const Vec<T>& 
Vec<T>::
makeUnit()
{
  return ((*this) = 1);
}

// sum all entries of a vector
template<class T> 
T
Vec<T>::
sum() const
{
  T mySum = 0;
  for (unsigned i = 0; i < this->size(); i++)
    mySum += (*this)(i);
  return mySum;
}

// euclidean norm
template<class T> 
T
Vec<T>::
norm() const
{
  return sqrt((*this) * (*this));
}

// maximum element in the vector
template<class T> 
T
Vec<T>::
max() const
{
  return *max_element(begin(), end());
}

// minimum element in the vector
template<class T> 
T
Vec<T>::
min() const
{
  return *min_element(begin(), end());
}

// print out a vector
template<class T> 
ostream&
operator<<(ostream& outputStream, const Vec<T>& obj)
{
  unsigned size = obj.size();
  outputStream << "{";
  for (unsigned i = 0; i < size-1; i++)
    outputStream << obj(i) << ",";
  outputStream << obj(size-1) << "}";
  return outputStream;
}

/******************************************************************************
*                                MATRIX CLASS: Mat                            *
******************************************************************************/

// class definition
template <class T>
class Mat 
{
public:
  Mat();
  Mat(int rows, int cols);
  Mat(int rows, int cols, T typeVal);
  Mat(const Mat<T>& rhsObj);
  const Mat<T>& operator=(const Mat<T>& rhsObj);
  const Mat<T>& operator=(T typeVal);
  const Mat<T>& operator+=(const Mat<T>& obj2);
  const Mat<T>& operator-=(const Mat<T>& obj2);
  const Mat<T>& operator*=(T typeVal);
  const Mat<T>& operator*=(const Mat<T>& obj2);
  const Mat<T>& operator/=(T typeVal);
  const Mat<T> operator+(const Mat<T>& obj2) const;
  const Mat<T> operator-(const Mat<T>& obj2) const;
  const Mat<T> operator*(T typeVal) const;
  const Mat<T> operator*(const Mat<T>& obj2) const;
  const Vec<T> operator*(const Vec<T>& obj2) const;
  const Mat<T> operator/(T typeVal) const;
  const Mat<T> operator-() const;
  T& operator()(int ind_i, int ind_j);
  const T& operator()(int ind_i, int ind_j) const;
  void setMyMat(const vector< vector<double> >& obj) const;
  const vector< vector<T> > getMyMat() const;
  unsigned rows() const;
  unsigned cols() const;
  void push_back(const Vec<T>& obj);
  void clear();
  const Mat<T> transpose() const;
  const Mat<T>& makeTranspose(); 
  const Mat<T>& makeIdentity();
  const Mat<T>& makeNull();
  const Mat<T>& makeUnit();
  const Vec<T> getRow(int row_i) const;
  const Vec<T> getCol(int col_i) const;
  const bool isSquare() const;
  T smallDet() const;
  const Mat<T> smallInv() const;
  const Mat<T> largeSymmInv() const;
  T norm1() const;
  const T smallCond1() const;
  const T largeSymmCond1() const;
  T sumCol(int col_i) const;
  T sumRow(int row_i) const;
  friend ostream& operator<< <T>(ostream& outputStream, const Mat<T>& obj);
  ~Mat();
private:
  vector< vector<T> > myMat_;
};

// constructors
template<class T> 
Mat<T>::
Mat()
{
}

template<class T> 
Mat<T>::
Mat(int rows, int cols)
{
  myMat_ = vector< vector<T> >(rows, vector<T>(cols));
}

template<class T> 
Mat<T>::
Mat(int rows, int cols, T typeVal)
{
  myMat_ = vector< vector<T> >(rows, vector<T>(cols, typeVal));
}

template<class T> 
Mat<T>::
Mat(const Mat& rhsObj)
{
  myMat_ = rhsObj.myMat_;
}

// destructor
template<class T> 
Mat<T>::
~Mat()
{
}

// assignment operators
template<class T> 
const Mat<T>& 
Mat<T>::
operator=(const Mat<T>& rhsObj)
{
  myMat_ = rhsObj.myMat_;
  return *this;
}

template<class T> 
const Mat<T>& 
Mat<T>::
operator=(T typeVal)
{
  for (unsigned i = 0; i < this->rows(); i++)
    for (unsigned j = 0 ; j < this->cols(); j++)
      (*this)(i,j) = typeVal;
  return *this;
}

// adding a matrix to the current matrix
template <class T>
const Mat<T>& 
Mat<T>::
operator+=(const Mat<T>& obj2)
{
  bool isTrue = (this->rows() != obj2.rows()) || (this->cols() != obj2.cols());
  if (isTrue)
  {
    cout << "ERROR: can't add 2 matrices of different size." << endl;
		exit(1);
  }
  for (unsigned i = 0; i < obj2.rows(); i++)
    for (unsigned j = 0; j < obj2.cols(); j++)
      (*this)(i,j) += obj2(i,j);
  return *this;
}

// subtracting a matrix from the current matrix
template<class T>
const Mat<T>&
Mat<T>::
operator-=(const Mat<T>& obj2)
{
  bool isTrue = (this->rows() != obj2.rows()) || (this->cols() != obj2.cols());
  if (isTrue)
  {
    cout << "ERROR: can't add 2 matrices of different size." << endl;
		exit(1);
  }
  for (unsigned i = 0; i < obj2.rows(); i++)
    for (unsigned j = 0; j < obj2.cols(); j++)
      (*this)(i,j) -= obj2(i,j);
  return *this;
} 

// multiplying the current matrix by a scalar
template<class T>
const Mat<T>&
Mat<T>::
operator*=(T typeVal)
{
  for (unsigned i = 0; i < this->rows(); i++)
    for (unsigned j = 0; j < this->cols(); j++)
      (*this)(i,j) *= typeVal;
  return *this;
} 

// multiplying the current matrix by a matrix
template<class T> 
const Mat<T>& 
Mat<T>::
operator*=(const Mat<T>& obj2)
{
  // check if inner dimensions coincide
  bool isTrue = this->cols() != obj2.rows();
  if (isTrue)
  {
    cout << "ERROR: can't multiply two matrices of different ";
    cout << "inner dimension." << endl;
    exit(1);
  }
  else
  {
    Mat<T> temp(this->rows(), obj2.cols());
    for (unsigned i = 0; i < this->rows(); i++)
    {
      for (unsigned j = 0; j < obj2.cols(); j++)
      {
        T sum = 0;
        for (unsigned k = 0; k < obj2.rows(); k++)
          sum += (*this)(i,k) * obj2(k,j);
        temp(i,j) = sum;
      }
    }
    return ((*this) = temp);
  }
}

// dividing the current matrix by a scalar
template<class T>
const Mat<T>&
Mat<T>::
operator/=(T typeVal)
{
  for (unsigned i = 0; i < this->rows(); i++)
    for (unsigned j = 0; j < this->cols(); j++)
      (*this)(i,j) /= typeVal;
  return *this;
} 

// matrix3 = matrix1 + matrix2
template<class T> 
const Mat<T> 
Mat<T>::
operator+(const Mat<T>& obj2) const
{
  bool isTrue = (this->rows() != obj2.rows()) || (this->cols() != obj2.cols());
  if (isTrue)
  {
    cout << "ERROR: can't add 2 matrices of different size." << endl;
		exit(1);
  }
  return (Mat<T>(*this) += obj2);
} 

// matrix3 = matrix1 - matrix2
template<class T> 
const Mat<T> 
Mat<T>::
operator-(const Mat<T>& obj2) const
{
  bool isTrue = (this->rows() != obj2.rows()) || (this->cols() != obj2.cols());
  if (isTrue)
  {
    cout << "ERROR: can't add 2 matrices of different size." << endl;
		exit(1);
  }
  return (Mat<T>(*this) -= obj2);
}

// matrix2 = matrix1 * scalar
template<class T> 
const Mat<T> 
Mat<T>::
operator*(T typeVal) const
{
  return (Mat<T>(*this) *= typeVal);
}

// vector2 = matrix1 * vector1
template<class T> 
const Vec<T> 
Mat<T>::
operator*(const Vec<T>& obj2) const
{
  bool isTrue = this->cols() != obj2.size();
  if (isTrue)
  {
    cout << "ERROR: can't multiply a matrix by a vector";
    cout << "of different inner dimension." << endl;
		exit(1);
  }
  Vec<T> temp(this->rows());
  for (unsigned i = 0; i < this->rows(); i++)
  {
    T sum = 0;
    for (unsigned j = 0; j < obj2.size(); j++)
    {
      sum += (*this)(i,j) * obj2(j);
    }
    temp(i) = sum;
  }
  return temp;
}

// matrix3 = matrix1 * matrix2
template<class T> 
const Mat<T> 
Mat<T>::
operator*(const Mat<T>& obj2) const
{
  return (Mat<T>(*this) *= obj2);
}

// matrix2 = matrix1 / scalar
template<class T> 
const Mat<T> 
Mat<T>::
operator/(T typeVal) const
{
  return (Mat<T>(*this) /= typeVal);
}

// overloading unary operator: the negative of ...
template<class T>
const Mat<T>
Mat<T>::
operator-() const
{
  return (Mat<T>(*this) * (-1));
}

// overload () only to read. changes are not allowed due to "const" 
// after the function prototype
template<class T>
const T&
Mat<T>::
operator()(int ind_i, int ind_j) const
{
  return myMat_[ind_i][ind_j];
} 

// overload () to read and/or change values by reference
template<class T>
T&
Mat<T>::
operator()(int ind_i, int ind_j)
{
  return myMat_[ind_i][ind_j];
}

// directly set myMat_ with an object of std::vector
template<class T>
void
Mat<T>::
setMyMat(const vector< vector<double> >& obj) const
{
  myMat_ = obj;
}

// get a copy of the private variable myMat_
template<class T>
const vector< vector<T> >
Mat<T>::
getMyMat() const
{
  return myMat_;
}

// get the number of rows of a matrix
template<class T> 
unsigned
Mat<T>::
rows() const
{
  return (myMat_.size());
}

// get the number of columns of a matrix
template<class T> 
unsigned
Mat<T>::
cols() const
{
  return (myMat_[0].size());
}

// push a vector into the first available empty row
template<class T> 
void
Mat<T>::
push_back(const Vec<T>& obj)
{
  myMat_.push_back(obj.getMyVec());
}

// overload std::vector clear.
// clear all vectors from the matrix
template<class T> 
void
Mat<T>::
clear()
{
  myMat_.clear();
}

// create a transpose of a matrix
template<class T> 
const Mat<T> 
Mat<T>::
transpose() const
{
  Mat<T> temp(this->cols(), this->rows());
  for (unsigned i = 0; i < this->cols(); i++)
    for (unsigned j = 0; j < this->rows(); j++)
      temp(i,j) = (*this)(j,i);
  return temp;
}

// tansfrom the current matrix into its transpose
template<class T> 
const Mat<T>&
Mat<T>::
makeTranspose()
{
  return (*this = (*this).transpose());
}

// transform the current matrix to Identity matrix
template<class T> 
const Mat<T>& 
Mat<T>::
makeIdentity()
{
  for (unsigned i = 0; i < this->rows(); i++)
    for (unsigned j = 0; j < this->cols(); j++)
    {
      if (i == j) 
        (*this)(i,j) = 1;
      else
        (*this)(i,j) = 0;
    }
  return *this;
}

// transform the current matrix to null matrix
template<class T> 
const Mat<T>& 
Mat<T>::
makeNull()
{
  return ((*this) = 0);
}

// transform the current matrix to unit matrix
template<class T> 
const Mat<T>& 
Mat<T>::
makeUnit()
{
  return ((*this) = 1);
}

// get a row of a matrix in a vector
template<class T> 
const Vec<T> 
Mat<T>::
getRow(int row_i) const
{
  Vec<T> temp(this->cols());
  for (unsigned i = 0; i < this->cols(); i++)
    temp(i) = (*this)(row_i-1,i);
  return temp;
}

// get a column of a matrix in a vector
template<class T> 
const Vec<T> 
Mat<T>::
getCol(int col_i) const
{
  Vec<T> temp(this->rows());
  for (unsigned i = 0; i < this->rows(); i++)
    temp(i) = (*this)(i,col_i-1);
  return temp;
}

// check if a matrix is square
template<class T> 
const bool 
Mat<T>::
isSquare() const
{
  return (this->cols() == this->rows());
}

// compute the determinant of a small square matrix
// (max. 3x3 matrix)
template<class T> 
T 
Mat<T>::
smallDet() const
{
  bool isTrue = (this->isSquare()) && (this->rows() <= 3);
  if (isTrue)
  {
    T det;
    if (this->rows() == 1)
    {
      det = (*this)(0,0);
    }
    else if (this->rows() == 2)
    {
      det = (*this)(0,0) * (*this)(1,1) - (*this)(0,1) * (*this)(1,0);
    }
    else if (this->rows() == 3)
    {
      det = (*this)(0,0) * ((*this)(2,2) * (*this)(1,1) - (*this)(2,1) * (*this)(1,2))
             - (*this)(1,0) * ((*this)(2,2) * (*this)(0,1) - (*this)(2,1) * (*this)(0,2))
             + (*this)(2,0) * ((*this)(1,2) * (*this)(0,1) - (*this)(1,1) * (*this)(0,2));
    }
    return det;
  }
  else
  {
    cout << "ERROR: can't compute the determinant of a non-square matrix ";
    cout << "or a square matrix larger than 3x3" << endl;
    exit(1);
  }
}

// compute the inverse of a small square matrix
// (max. 3x3 matrix)
template<class T> 
const Mat<T> 
Mat<T>::
smallInv() const
{
  bool isTrue = (this->isSquare()) && (this->rows() <= 3);
  if (isTrue)
  {
    Mat<T> temp(this->rows(),this->cols());
    if (this->rows() == 1)
    {
      T det = this->smallDet();
      //if ( (abs(det - 0.0) < 2.0*(numeric_limits<double>::epsilon())) )
      //{
      //  cout << "Warning: Inverting a matrix which is singular to ";
      //  cout << "working precision." << endl; 
      //}
      temp(0,0) = 1 / det;
    }
    else if (this->rows() == 2)
    {
      T det = this->smallDet();
      //if ( (abs(det - 0.0) < 2.0*(numeric_limits<double>::epsilon())) )
      //{
      //  cout << "Warning: Inverting a matrix which is singular to ";
      //  cout << "working precision." << endl; 
      //} 
      T invDet = 1/det;
      temp(0,0) = (*this)(1,1) * invDet;
      temp(0,1) = -(*this)(0,1) * invDet;
      temp(1,0) = -(*this)(1,0) * invDet;
      temp(1,1) = (*this)(0,0) * invDet;
    }
    else if (this->rows() == 3)
    {
      T det = this->smallDet();
      //if ( (abs(det - 0.0) < 2.0*(numeric_limits<double>::epsilon())) )
      //{
      //  cout << "Warning: Inverting a matrix which is singular to ";
      //  cout << "working precision." << endl; 
      //} 
      T invDet = 1/det;
      temp(0,0) = ((*this)(2,2) * (*this)(1,1) - (*this)(2,1) * (*this)(1,2)) * invDet;
      temp(0,1) = - ((*this)(2,2) * (*this)(0,1) - (*this)(2,1) * (*this)(0,2)) * invDet;
      temp(0,2) = ((*this)(1,2) * (*this)(0,1) - (*this)(1,1) * (*this)(0,2)) * invDet;
      temp(1,0) = - ((*this)(2,2) * (*this)(1,0) - (*this)(2,0) * (*this)(1,2)) * invDet;
      temp(1,1) = ((*this)(2,2) * (*this)(0,0) - (*this)(2,0) * (*this)(0,2)) * invDet;
      temp(1,2) = - ((*this)(1,2) * (*this)(0,0) - (*this)(1,0) * (*this)(0,2)) * invDet;
      temp(2,0) = ((*this)(2,1) * (*this)(1,0) - (*this)(2,0) * (*this)(1,1)) * invDet;
      temp(2,1) = - ((*this)(2,1) * (*this)(0,0) - (*this)(2,0) * (*this)(0,1)) * invDet;
      temp(2,2) = ((*this)(1,1) * (*this)(0,0) - (*this)(1,0) * (*this)(0,1)) * invDet;
    }
    // check if the matrix is near to singular
    // 1-norm of the calling object
    T n1 = this->norm1();
    // 1-norm of the inverse of the calling object
    T n2 = temp.norm1();
    // condition number
    T condNum = n1*n2;
    if ( (1 / condNum) < 1e-5 )
      cout << "Warning: Inverting a matrix which is nearly singular." << endl;
    // 
    return temp;
  }
  else
  {
    cout << "ERROR: can't compute the inverse of a non-square matrix ";
    cout << "or a square matrix larger than 3x3" << endl;
    exit(1);
  }
}

// compute the inverse of a large symmetric positive definite 
// dense square matrix
template<class T> 
const Mat<T> 
Mat<T>::
largeSymmInv() const
{
  // TO DO: might be more efficient to compute the inverse with 
  // clapack library instead. Functions: dpotrf_ and dpotri_
  bool isTrue = this->isSquare();
  if (isTrue)
  {
    int size = (int)this->rows();
    Mat<T> temp(size,size);
    Vec<T> u(size);
    Vec<T> f(size,0);
    // solve "size" linear systems to find the inverse
    int stat = 0;
    for (int i = 0; i < size; i++)
    {
      f(i) = 1.0;
      u = symmDenseLinearSolver(*this,f,&stat);
      if (stat != 0)
      {
        cout << "Error: Matrix might be singular." << endl;
        exit(1); 
      }
      for (int j = 0; j < size; j++)
        temp(j,i) = u(j);
      f(i) = 0.0;
    }
    //
    return temp;
  }
  else
  {
    cout << "ERROR: can't compute the inverse of a non-square matrix." << endl;
    exit(1);
  }
}

// compute the 1-norm of a square matrix.
// naive implementation ... not good for large matrices
template<class T> 
T
Mat<T>::
norm1() const
{
  T max = 0;
  for (unsigned j = 0; j < this->cols(); j++)
  {
    T sum = 0;
    for (unsigned i = 0; i < this->rows(); i++)
      sum = sum + abs((*this)(i,j));
    if (sum > max) max = sum;
  }
  return max;
}

// compute the condition number of a small square matrix
// with respect to inversion using the 1-norm
// (max. 3x3 matrix)
template<class T> 
const T 
Mat<T>::
smallCond1() const
{
  bool isTrue = (this->isSquare()) && (this->rows() <= 3);
  if (isTrue)
  {
    // 1-norm of the calling object
    T n1 = this->norm1();
    // inverse of the calling object
    Mat<T> temp = this->smallInv();
    // 1-norm of the inverse of the calling object
    T n2 = temp.norm1();
    // return the condition number
    return (n1*n2);
  }
  else
  {
    cout << "ERROR: can't compute the condition number of a non-square matrix ";
    cout << "or a square matrix larger than 3x3" << endl;
    exit(1);
  }
}

// compute the condition number of a large symmetric square matrix
// with respect to inversion using the 1-norm
template<class T> 
const T 
Mat<T>::
largeSymmCond1() const
{
  bool isTrue = this->isSquare();
  if (isTrue)
  {
    // 1-norm of the calling object
    T n1 = this->norm1();
    // inverse of the calling object
    Mat<T> temp = this->largeSymmInv();
    // 1-norm of the inverse of the calling object
    T n2 = temp.norm1();
    // return the condition number
    return (n1*n2);
  }
  else
  {
    cout << "ERROR: can't compute the condition number of ";
    cout << "a non-square matrix." << endl;
    exit(1);
  }
}

// sum all entries of a column of a matrix
template<class T> 
T
Mat<T>::
sumCol(int col_i) const
{
  T mySum = 0;
  for (unsigned i = 0; i < this->rows(); i++)
    mySum += (*this)(i,col_i-1);
  return mySum;
}

// sum all entries of a row of a matrix
template<class T> 
T
Mat<T>::
sumRow(int row_i) const
{
  T mySum = 0;
  for (unsigned j = 0; j < this->cols(); j++)
    mySum += (*this)(row_i-1,j);
  return mySum;
}

// print out a matrix
template<class T> 
ostream&
operator<<(ostream& outputStream, const Mat<T>& obj)
{
  unsigned rows = obj.rows();
  unsigned cols = obj.cols();
  for (unsigned i = 0; i < rows-1; i++)
  {
    outputStream << "{";
    for (unsigned j = 0; j < cols-1; j++)
      outputStream << obj(i,j) << ",";
    outputStream << obj(i,cols-1) << "}" << endl;
  }
  outputStream << "{";
  for (unsigned j = 0; j < cols-1; j++)
    outputStream << obj(rows-1,j) << ",";
  outputStream << obj(rows-1,cols-1) << "}";
  return outputStream;
}

/******************************************************************************
*                         NON-MEMBER OVERLOADINGS                             *
******************************************************************************/

// overloading * as a non-member since the first argument 
// is not an object of the class Vec
template<class T, class U>
const Vec<T>
operator*(const U typeVal, const Vec<T>& obj)
{
  return (obj*typeVal);
}

// overloading * as a non-member since the first argument 
// is not an object of the class Mat
template<class T, class U>
const Mat<T>
operator*(const U typeVal, const Mat<T>& obj)
{
  return (obj*typeVal);
}

/******************************************************************************
*                    NON-MEMBER FUNCTIONS: LINEAR SOLVERS                     *
*                                                                             *
*            All solvers have been implemented using TAUCS library.           *
*                                                                             *
* References:                                                                 *
* ===========                                                                 *
* [1] Toledo S., Chen D., Rotkin V. TAUCS: A library of sparse linear solvers.*
* Version 2.2. September 4, 2003. http://www.tau.ac.il/~stoledo/taucs/        *
*                                                                             *
******************************************************************************/

// Solve the linear system of equations K u = f, where K is a dense square    
// positive definite symmetric matrix, u is the solution vector, and f is 
// the right-hand side vector. The function reads the full matrix A and store 
// its upper triangle by rows. TAUCS library is used to solve the system.                        
template<class T> 
const Vec<T>
symmDenseLinearSolver(const Mat<T>& K, Vec<T>& f, int* stat)
{
	// form the vector containing the upper half matrix
  // of a dense symmetric matrix
  int neq = (int)f.size(); // number of equations
	int nnan = (neq * neq - neq) / 2 + neq;
  Vec<T> Kt(nnan); // vector containing upper triangle of symmetric matrix K
  Vec<int> Kindex(nnan); // vector containing column indices of row elements in K
  Vec<int> dptr(neq+1); // vector containing pointer to diagonal terms in K
  // use TAUCS library to solve the system
	dptr(0) = 0;
	int r = 0;
	for (int i = 0; i < neq; i++) // loop over rows
	{
		for (int j = i; j < neq; j++) // loop over columns
		{
      Kt(r) = K(i,j); // store the upper triangular matrix
      Kindex(r) = j;
      r++;
		}
		dptr(i+1) = r;
	}
  // create and setup TAUCS matrix to solve Ax=b in CCS format
  taucs_ccs_matrix A;
  A.n = dptr.size() - 1;
  A.m = dptr.size() - 1;
  A.flags = (TAUCS_DOUBLE | TAUCS_SYMMETRIC | TAUCS_LOWER);
  A.colptr = &dptr(0);
  A.rowind = &Kindex(0);
  A.values.d = &Kt(0);
  // create right hand side vector and unknown vector to solve Ax=b
  taucs_double* b = &f(0); 
  Vec<T> u(neq);
  taucs_double* x = &u(0); 
  // solve the linear system Ax=b
  void* F = NULL;
  char* options[] = {"taucs.factor.LLT=true", NULL};
  void* opt_arg[] = { NULL };
  int i = taucs_linsolve(&A, &F, 1, x, b, options, opt_arg);
  if (i != TAUCS_SUCCESS)
  {
    cout << "Solution error." << endl;
    if (i==TAUCS_ERROR) {*stat = 1; cout << "Generic error. Matrix might be singular" << endl;}
    if (i==TAUCS_ERROR_NOMEM) {cout << "NOMEM error." << endl; exit(1);}
    if (i==TAUCS_ERROR_BADARGS) {cout << "BADARGS error." << endl; exit(1);}
    if (i==TAUCS_ERROR_MAXDEPTH) {cout << "MAXDEPTH error." << endl; exit(1);}
    if (i==TAUCS_ERROR_INDEFINITE) {cout << "NOT POSITIVE DEFINITE error." << endl; exit(1);}
  }
  else
  {
    *stat = 0;
  }
  // deallocate factorization
  taucs_linsolve(NULL, &F, 0, NULL, NULL, NULL, NULL);
  //
  return u;
}

// Solve the linear system of equations K u = f, where K is a sparse square    
// positive definite symmetric matrix, u is the solution vector, and f is the 
// right-hand side vector. The function reads the full matrix A and store its upper 
// triangle by rows in compact form. TAUCS library is used to solve the system.                        
template<class T> 
const Vec<T>
symmSparseLinearSolver(const Mat<T>& K, Vec<T>& f, int* stat)
{
	// form the vector containing the upper half matrix
  // of a sparse symmetric matrix
  int neq = (int)f.size(); // number of equations
	int nnan = (neq * neq - neq) / 2 + neq;
  Vec<T> Kt(nnan); // vector containing upper triangle of symmetric matrix K
  Vec<int> Kindex; // vector containing column indices of row elements in K
  Vec<int> dptr;   // vector containing pointer to diagonal terms in K
  // create compact row matrix
  double tol = 5.0*(numeric_limits<double>::epsilon());
  int k = 0;
  int r = 0;
  dptr.push_back(0); // first term is always zero
  for (int i = 0; i < neq; i++)
  {
    for (int j = i; j < neq; j++)
    {
      if (abs(K(i,j)) > tol)
      {
        Kt(r) = K(i,j);
        Kindex.push_back(j);
        r++;
      }
      k++;
    }
    dptr.push_back(r);
  }
  // free memory not needed at the end of bigK
  Kt.resize(r); 
  // create and setup TAUCS matrix to solve Ax=b in CCS format
  taucs_ccs_matrix A;
  A.n = dptr.size() - 1;
  A.m = dptr.size() - 1;
  A.flags = (TAUCS_DOUBLE | TAUCS_SYMMETRIC | TAUCS_LOWER);
  A.colptr = &dptr(0);
  A.rowind = &Kindex(0);
  A.values.d = &Kt(0);
  // create right hand side vector and unknown vector to solve Ax=b
  taucs_double* b = &f(0); 
  Vec<T> u(neq);
  taucs_double* x = &u(0); 
  // solve the linear system Ax=b
  void* F = NULL;
  char* options[] = {"taucs.factor.LLT=true", NULL};
  void* opt_arg[] = { NULL };
  int i = taucs_linsolve(&A, &F, 1, x, b, options, opt_arg);
  if (i != TAUCS_SUCCESS)
  {
    cout << "Solution error." << endl;
    if (i==TAUCS_ERROR) {*stat = 1; cout << "Generic error. Matrix might be singular" << endl;}
    if (i==TAUCS_ERROR_NOMEM) {cout << "NOMEM error." << endl; exit(1);}
    if (i==TAUCS_ERROR_BADARGS) {cout << "BADARGS error." << endl; exit(1);}
    if (i==TAUCS_ERROR_MAXDEPTH) {cout << "MAXDEPTH error." << endl; exit(1);}
    if (i==TAUCS_ERROR_INDEFINITE) {cout << "NOT POSITIVE DEFINITE error." << endl; exit(1);}
  }
  else
  {
    *stat = 0;
  }
  // deallocate factorization
  taucs_linsolve(NULL, &F, 0, NULL, NULL, NULL, NULL);
  //
  return u;
}

// Solve the linear system of equations K u = f, where K is a sparse square    
// positive definite symmetric matrix, u is the solution vector, and f is the 
// right-hand side vector. The function reads a vector with the upper or lower 
// part of matrix A stored by rows or columns and creates a compact format. 
// TAUCS library is used to solve the system.                        
template<class T> 
const Vec<T>
symmSparseLinearSolver(Vec<T>& K, Vec<T>& f, int* stat)
{
  // create compact row matrix
  int neq = (int)f.size(); // number of equations
  Vec<int> Kindex; // vector containing column indices of row elements in K
  Vec<int> dptr;   // vector containing pointer to diagonal terms in K
  double tol = 5.0*(numeric_limits<double>::epsilon());
  int k = 0;
  int r = 0;
  dptr.push_back(0); // first term is always zero

  for (int i = 0; i < neq; i++)
  {
    for (int j = i; j < neq; j++)
    {
      if (fabs(K(k)) > tol)
      {
        K(r) = K(k);
        Kindex.push_back(j);
        r++;
      }
      k++;
      cout << k << endl;
    }
    dptr.push_back(r);
  }

  // free memory not needed at the end of bigK
  K.resize(r); 
  // create and setup TAUCS matrix to solve Ax=b in CCS format
  taucs_ccs_matrix A;
  A.n = dptr.size() - 1;
  A.m = dptr.size() - 1;
  A.flags = (TAUCS_DOUBLE | TAUCS_SYMMETRIC | TAUCS_LOWER);
  A.colptr = &dptr(0);
  A.rowind = &Kindex(0);
  A.values.d = &K(0);
  // create right hand side vector and unknown vector to solve Ax=b
  taucs_double* b = &f(0); 
  Vec<T> u(neq);
  taucs_double* x = &u(0); 
  // solve the linear system Ax=b
  void* F = NULL;
  char* options[] = {"taucs.factor.LLT=true", NULL};
  void* opt_arg[] = { NULL };
  int i = taucs_linsolve(&A, &F, 1, x, b, options, opt_arg);
  if (i != TAUCS_SUCCESS)
  {
    cout << "Solution error." << endl;
    if (i==TAUCS_ERROR) {*stat = 1; cout << "Generic error. Matrix might be singular" << endl;}
    if (i==TAUCS_ERROR_NOMEM) {cout << "NOMEM error." << endl; exit(1);}
    if (i==TAUCS_ERROR_BADARGS) {cout << "BADARGS error." << endl; exit(1);}
    if (i==TAUCS_ERROR_MAXDEPTH) {cout << "MAXDEPTH error." << endl; exit(1);}
    if (i==TAUCS_ERROR_INDEFINITE) {cout << "NOT POSITIVE DEFINITE error." << endl; exit(1);}
  }
  else
  {
    *stat = 0;
  }
  // deallocate factorization
  taucs_linsolve(NULL, &F, 0, NULL, NULL, NULL, NULL);
  //
  return u;
}

#endif

