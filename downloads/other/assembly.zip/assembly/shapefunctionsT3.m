% function [phi,phider]=shapefunctionsT3(xy,x)
%
% Purpose
% =======                                                                      
% Compute 3-node triangle shape functions and their derivatives in cartesian
% coordinates at samplig point x
%
% Variables
% =========
% xy       : element nodal coordinates [n1x n1y; n2x n2y; n3x n3y]
% x        : sampling point in cartesian coordinates [x y]
%
% Return
% ======
% phi      : shape functions [phi1 phi2 phi3]
% phider   : shape functions derivatives [phi1,x phi1,y; ...; phi3,x phi3,y]
%
% References
% ==========
% [1] Zienkiewicz O.C., Taylor R.L., The Finite Element Method. Fifth
% Edition. Volume 1, The Basis. Butterworth-Heinemann, MA, USA.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function [phi,phider]=shapefunctionsT3(xy,x)

% area of the triangle
area=1.0/2.0*abs(xy(1,1)*(xy(3,2)-xy(2,2))+...
                 xy(3,1)*(xy(2,2)-xy(1,2))+...
                 xy(2,1)*(xy(1,2)-xy(3,2)));
   
% constants
a1=xy(2,1)*xy(3,2)-xy(3,1)*xy(2,2); a2=xy(3,1)*xy(1,2)-xy(1,1)*xy(3,2);
a3=xy(1,1)*xy(2,2)-xy(2,1)*xy(1,2); b1=xy(2,2)-xy(3,2); b2=xy(3,2)-xy(1,2); 
b3=xy(1,2)-xy(2,2); c1=xy(3,1)-xy(2,1); c2=xy(1,1)-xy(3,1); c3=xy(2,1)-xy(1,1);
pp=1/(2*area);

% shape functions
N1=pp*(a1+b1*x(1)+c1*x(2)); 
N2=pp*(a2+b2*x(1)+c2*x(2));
N3=pp*(a3+b3*x(1)+c3*x(2));
phi=[N1; N2; N3];

% shape functions derivatives
N1x=pp*b1; N1y=pp*c1; N2x=pp*b2; N2y=pp*c2; N3x=pp*b3; N3y=pp*c3;
phider=[N1x N1y; N2x N2y; N3x N3y]; 









    
    
    







