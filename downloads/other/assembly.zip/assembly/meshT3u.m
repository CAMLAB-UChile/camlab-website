% function [ncoord,connect]=meshT3u(xmin,xmax,ymin,ymax,divx,divy)
%
% Purpose
% =======                                                                      
% Create uniform mesh of 3-node triangles on the domain (xmin,xmax)x(ymin,ymax)
%
% Variables
% =========
% xmin     : x-coordinate minimum value
% xmax     : x-coordinate maximum value
% ymin     : y-coordinate minimum value
% ymax     : y-coordinate maximum value
% divx     : number of divisions along x-direction
% divy     : number of divisions along y-direction
%
% Return
% ======
% ncoord   : nodal coordinates [x1 y1; ...; xn yn]
% connect  : element nodal connectivity [nod1 nod2 nod3; ...; nod1 nod2 nod3]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function [ncoord,connect]=meshT3u(xmin,xmax,ymin,ymax,divx,divy)

numnod=(divx+1)*(divy+1);     % number of nodes
numel=divx*divy*2;            % number of elements 
ncoord=zeros(numnod,2);       % nodal coordinates
connect=zeros(numel,3);       % element nodal connectivity
dx=(xmax-xmin)/divx;          % nodal spacing in x-direction 
dy=(ymax-ymin)/divy;          % nodal spacing in y-direction

% create nodal coordinates
k=1;
y=ymin;
for i=1:(divy+1)
  x=xmin; 
  for j=1:(divx+1)
    ncoord(k,:)=[x y];
    x=x+dx;
    k=k+1;
  end
  y=y+dy;
end

% create element connectivities
k=1;
node=1;
for i=1:divy
  for j=1:divx
    connect(k,:)=[node node+1 node+divx+2];
    connect(k+1,:)=[node node+divx+2 node+divx+1];
    node=node+1;
    k=k+2;
  end
  node=node+1;
end




    
    
    







