/*******************************************************************************
*                               MeshFree++                                     *
*                               ==========                                     *
*                                                                              *
*   A C++ class that provides a unified meshfree basis function computation.   *
*                                                                              *
*  Created by  : Alejandro A. Ortiz                                            *
*  E-mail      : alortiz@ucdavis.edu                                           *
*  Version     : 1.0                                                           *
*  Date        : September 23, 2009                                            *
*                                                                              *
*                         Copyright and License                                *
*                         =====================                                *
*                                                                              *
*                   MeshFree++ 1.0, Copyright (c) 2009                         *
*                          by Alejandro A. Ortiz,                              *
*                           alortiz@ucdavis.edu                                *
*             Department of Civil & Environmental Engineering,                 *
*             University of California, Davis, CA 95616, U.S.A.                *
*                           All Rights Reserved.                               *
*                                                                              *
*    Your use or distribution of MeshFree++ Class or any derivative code       *
*    implies that you agree to this License.                                   *
*                                                                              *
*    This program is distributed in the hope that it will be useful,           *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. This program is      *
*    free software and you can choose any of the following license terms:      *
*                                                                              *
*    1) GNU Lesser General Public License (LGPL) as published by the Free      *
*       Software Foundation; either version 3 of the License, or(at your       *
*       option) any later version. For details see copy of LGPL in folder      *
*       License\gnu of this distribution.                                      *
*                                                                              *
*    2) Alternatively, you may choose to comply with the following             * 
*       UMFPACK-style license:                                                 *
*                                                                              *
*       THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY           *
*       EXPRESSED OR IMPLIED. ANY USE IS AT YOUR OWN RISK.                     *
*                                                                              *
*       Permission is hereby granted to use or copy this program, provided     * 
*       that the Copyright, this License, and the Availability of the          * 
*       original version is retained on all copies. User documentation of      *
*       any code that uses this code or any derivative code must cite the      * 
*       Copyright, this License, the Availability note, and "Used by           *
*       permission". Permission to modify the code and to distribute           * 
*       modified code is granted, provided the Copyright, this License,        * 
*       and the Availability note are retained, and a notice that the code     * 
*       was modified is included. This software is provided to you free of     * 
*       charge.                                                                * 
*                                                                              *
*    MeshFree++ uses MathVec++. You must comply with MathVec++ license terms.  * 
*    For details see folder License of this distribution.                      *
*                                                                              *
*------------------------------------------------------------------------------*  
*                                                                              *
* Release notes                                                                *	
* =============                                                                *
* Version 1.0 (September 23, 2009): Compute first order maximum entropy basis  *
* functions (maxent) and first order moving least squares basis functions      *
* (mls).                                                                       *
*                                                                              *
*------------------------------------------------------------------------------*
*                                                                              *
* References                                                                   *
* =============                                                                *
* [1] Sukumar N., Wright R.W. Overview and construction of meshfree shape      *
* functions: From moving least squares to entropy approximants. Int. J.        *
* Numer. Meth. Engng 2007; 70(2):181-205.                                      *
*                                                                              *
* [2] Arroyo M., Ortiz M. Local maximum-entropy approximation schemes: a       *
* semaless bridge between finite elements and meshfree methods. Int. J.        *
* Numer. Meth. Engng 2006; 65(13):2167-2202.                                   *
*                                                                              *
* [3] Dolbow J., Belytschko T. An introduction to programming the meshless     *
* element free Galerkin method. Arch. Comput. Methods Eng. 1998; 5(3):207-242. *
*                                                                              *
*******************************************************************************/

#ifndef MESHFREE_H
#define MESHFREE_H

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <limits>
using namespace std;

#include "mathvec.h"

/*******************************************************************************
*                                                                              *
*                           MESHFREE CLASS DECLARATION                         *
*                           ==========================                         *
*                                                                              *
*******************************************************************************/
class MeshFree
{
public:
  MeshFree(const string& name, int dim, int nNodes, const Mat<double>& nodeCoord,
           const Vec<double>& xSample, const Vec<double>& nodeSpacing,
           double gamma, int order, int compute, bool autoIncreaseSupportSize,
           bool variousSamplePoints);
  MeshFree(const MeshFree& rhsObj);
  const MeshFree& operator=(const MeshFree& rhsObj);
  void setPhi(const Vec<double>& phi);
  void setPhiDer(const Mat<double>& phiDer); 
  void setContribute(const Vec<int>& contribute);
  void setLength(int length);
  void gaussian(double Tol_0);
  void cubicSpline();
  void quarticSpline();
  void constantWeight();
  const string name() const;
  int dim() const;
  int nNodes() const;
  double gamma() const;
  int order() const;
  int compute() const;
  bool variousSamplePoints() const;
  double nodeSpacing(int index) const;
  const Vec<double> nodeSpacing() const;
  double nodeCoord(int index_i, int index_j) const;
  double nodeCoordContribute(int index_i, int index_j) const;
  const Mat<double> nodeCoord() const;
  const Mat<double> nodeCoordContribute()const;
  double xSample(int index) const;
  const Vec<double> xSample() const;
  double xShift(int index_i, int index_j) const;
  double xShiftContribute(int index_i, int index_j) const;
  const Mat<double> xShift() const;
  const Mat<double> xShiftContribute() const;
  double phi(int index) const;
  const Vec<double> phi() const;
  double phiDer(int index_i, int index_j) const;
  const Mat<double> phiDer() const;
  int contribute(int index) const;
  const Vec<int> contribute() const;
  int length() const;
  double weightFun(int index) const;
  const Vec<double> weightFun() const;
  double weightFunDer(int index_i, int index_j) const;
  const Mat<double> weightFunDer() const;
  void consistencyCheck() const;
  ~MeshFree();
private:
  // variables
  string name_;                  // name of the meshfree method
  int dim_;                      // problem dimension (1, 2 or 3)
  int nNodes_;                   // total number of nodes
  double gamma_;                 // basis function support parameter (gamma for gaussian prior or alpha for splines priors)
  int compute_;                  // =1 for phi computation only, or =2 for both phi and phider 
  int order_;                    // order of the meshfree approximation
  Mat<double> nodeCoord_;        // nodal coordinates
  Vec<double> nodeSpacing_;      // characteristic nodal spacing
  Vec<double> xSample_;          // evaluation point
  bool variousSamplePoints_;     // =1 (true) for evaluation at one sample point, =0 (false) for evaluation at various sample points (controls if output file is appended or rewritten)
  bool constantNodeSpacing_;     // =1 (true) if max. node spacing (h_max) is used for all the domain, =0 (false) if each node has its own node spacing (h).
  bool autoIncreaseSupportSize_; // =1 (true) to auto increase support size when there is insufficient neighbors. =0 (false) otherwise
  Mat<double> xShift_;           // shifted coordinates 
  Vec<double> weightFun_;        // weight (kernel) function
  Mat<double> weightFunDer_;     // weight (kernel) function derivatives
  Vec<double> phi_;              // meshfree basis functions
  Mat<double> phiDer_;           // meshfree basis function derivatives
  Vec<int> contribute_;          // index of the nodes that contribute to phi and phiDer (neighbors)
  int length_;                   // length of contribute
  // functions
  void computeShiftedCoordinates();
  void neighbors(const Vec<double>& radius);
};

/*******************************************************************************
*                                                                              *
*                            MAXENT CLASS DECLARATION                          *
*                            ========================                          *
*                                                                              *
*******************************************************************************/
class Maxent : public MeshFree
{
public:
  // functions
  Maxent(int dim, int nNodes, const Mat<double>& nodeCoord,
         const Vec<double>& xSample, const Vec<double>& nodeSpacing,
         const string& weightName, double gamma, int order, int compute,
         bool autoIncreaseSupportSize, bool forceConsistencyCheck,
         bool variousSamplePoints, bool printAllResults,
         double rtol, int maxIter);
  Maxent(const Maxent& rhsObj);
  const Maxent& operator=(const Maxent& rhsObj);
  void computeMeshfree();
  void consistencyCheck() const;
  ~Maxent();
private:
  // variables
  string weightName_;           // name of the prior weight function
  bool printAllResults_;        // 0(false) or 1(true). When false, print just in case of failure in newton's convergence
  bool forceConsistencyCheck_;  // 0(false): don't run consistency check if not needed. 1(true): run consistency check, even if not needed
  double rtol_;                 // required newton's tolerance
  bool failure_;                // if newton's method fails to converge. 0(false) if not failed, 1(true) if failed
  int newtonIter_;              // number of Newton's iterations to converge
  int maxIter_;                 // maximum allowed Newton's iterations
  double newtonError_;          // Final residual error in the Newton's iterations
  Vec<double> newtonLambda_;    // final (converged or non-converged) lagrange multipliers
  // functions
  void computeWeight();  
  void computePhi(Vec<double>& phi);
  void functionOfLambda(const Vec<double>& lambda, Vec<double>& residual,
                        Mat<double>& jacobian, Vec<double>& phi) const;
  double stepSize(const double rtol_, const Vec<double>& lambda,
                  const Vec<double>& dlambda) const;
  double dualObjectiveFunction(const Vec<double>& lambda) const;
  void computePhiDer(const Vec<double>& phi, Mat<double>& phiDer) const;
  void phiDerMatrices(const Vec<double>& phi, Mat<double>& MA,
                      Mat<double>& H, Mat<double>& A, Vec<double>& mc) const;
  void printResults();
};

/*******************************************************************************
*                                                                              *
*                              MLS CLASS DECLARATION                           *
*                              =====================                           *
*                                                                              *
*******************************************************************************/
class Mls : public MeshFree
{
public:
  // functions
  Mls(int dim, int nNodes, const Mat<double>& nodeCoord,
      const Vec<double>& xSample, const Vec<double>& nodeSpacing,
      const string& weightName, double gamma, int order, int compute,
      bool autoIncreaseSupportSize, bool forceConsistencyCheck,
      bool variousSamplePoints, bool printAllResults);
  Mls(const Mls& rhsObj);
  const Mls& operator=(const Mls& rhsObj);
  void computeMeshfree();
  ~Mls();
private:
  // variables
  string weightName_;          // name of the weight function
  bool failure_;               // mls fails?: 0(false) or 1(true)
  bool printAllResults_;       // 0(false) or 1(true)
  bool forceConsistencyCheck_; // 0(false), don't run consistency check if not needed. 1(true), run consistency check, even if not needed
  // functions
  void computeWeight();  
  void computeMatrices(Mat<double>& bm, Mat<double>& bmDer,
                       Mat<double>& am, Mat<double>& amDer, 
                       Vec<double>& gv, int polyBasisLength);
  void computePhi(Vec<double>& phi, const Vec<double>& gv,
                  const Mat<double>& bm) const;
  void computePhiDer(const Mat<double>& am,
                     const Mat<double>& amDer, const Mat<double>& bm,
                     const Mat<double>& bmDer, const Vec<double>& gv,
                     int polyBasisLength, Mat<double>& phiDer) const;
  void printResults();
};

#endif


