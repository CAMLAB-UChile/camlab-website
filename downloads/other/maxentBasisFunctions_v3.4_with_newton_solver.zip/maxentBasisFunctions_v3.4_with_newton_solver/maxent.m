%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program computes the Maximum Entropy (MAXENT) basis functions and
% its gradients in 1D, 2D or 3D.
%
% Created by  : Alejandro A. Ortiz
% web         : www.cec.uchile.cl/~aortizb
% E-mail      : aortizb@ing.uchile.cl
% Version     : 3.4
% Date        : March 14, 2012
%
%              Department of Mechanical Engineering                  
%	           The University of Chile, Santiago, Chile.               
%                                                                              
%           Copyright (C) 2008-2012 Alejandro A. Ortiz                          
%                                                                               
%    This program is free software: you can redistribute it and/or modify      
%    it under the terms of the GNU General Public License as published by      
%    the Free Software Foundation, either version 2 of the License, or         
%    (at your option) any later version.                                       
%                                                                              
%    This program is distributed in the hope that it will be useful,           
%    but WITHOUT ANY WARRANTY; without even the implied warranty of            
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             
%    GNU General Public License for more details.                              
%                                                                              
%    You should have received a copy of the GNU General Public License         
%    along with this program; if not, write to the Free Software               
%    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA or see           
%    <http://www.gnu.org/licenses/>.                                           
%                                                                              
%--------------------------------------------------------------------------
%
% Release notes 
% =============
% Version 3.4 (March 2012): from now on each node carries its own prior
% function independently of whether the mesh uses "unstructured" capability
% or not. This will allow to eventually define different prior functions 
% among the nodes. As a consequence, one needs in any case to supply a 
% vector of size number of nodes containing gamma for each node. 
% This change affected prior.m function and inputdata.m function.
%
% Version 3.3 (January 2012): Fixed a bug in the "unstructured" capability.
% This affected the computation of the basis function support radius in 
% prior.m file and also inputdata.m function. For "unstructured" one needs 
% to supply a vector of size number of nodes containing gamma for each 
% node. If "unstructured" is not used only a scalar can be supplied as gamma.
%
% Version 3.2 (September 2010): Added capability for unstructured generated
% nodes. When an unstructured set of nodes is available, "unstructured"
% variable in inputdata.m file should be set to 1. This way, the support radius
% of basis functions is computed for each node independently.
%
% Version 3.1 (February 2010): Fixed minor errors in printing options. Improved
% function nodespacing.m
%
% Version 3/Release 2009.4 (August 2009): Change the way to find the
% neighbors. Add new function neighbors.m and update prior.m accordingly.
%
% Version 3/Release 2009.3 (August 2009): Correct a bug in
% phidermatrices.m. Add maxent iteration tolerance parameter "rtol" in
% inputdata.m
%
% Version 3/Release 2009.2 (April 2009): Constant prior added in order to
% obtain standard Shanoon/Jaynes entropy. In file: prior.m
%
% Version 3/Release 2009.1 (February 2009): Added option to specify whether 
% basis functions derivatives must be computed. Function getallmaxentdata.m
% changed by inputdata.m. Computes maxent for any prior and its corresponding
% gradient.
%
% Version 3/Release 2008.4 (May 2008)(THIS VERSION SUPERSEDES PAST VERSION 
% OF MAXENT in 1D): Computes MAXENT basis functions in 1d, 2D and 3D as detailed 
% in Reference [2] and its derivatives as detailed in Reference [3].
%
% Version 2/Release 2008.3 (May 2008): Shape functions derivatives added as
% detailed in Reference [3].
% 
% Version 2/Release 2008.2 (April 2008): Prior function added as detailed 
% in Reference [2]. When specifying prior function a Gaussian (RBF) weight 
% function is considered.
%
% Version 1/Release 2008.1 (March 2008): Compute MAXENT shape functions 
% using standard Shannon-Jaynes principle as detailed in Reference [1].
%
%--------------------------------------------------------------------------
%
% References 
% =============
% [1] Sukumar N. Construction of polygonal interpolants: a maximum entropy 
% approach. Int. J. Numer. Meth. Engng 2004; 61(12):2159-2181.
%
% [2] Sukumar N., Wright R.W. Overview and construction of meshfree shape
% functions: From moving least squares to entropy approximants. Int. J.
% Numer. Meth. Engng 2007; 70(2):181-205.
%
% [3] Arroyo M., Ortiz M. Local maximum-entropy approximation schemes: a
% semaless bridge between finite elements and meshfree methods. Int. J.
% Numer. Meth. Engng 2006; 65(13):2167-2202.
%
%--------------------------------------------------------------------------
%
% Input Data
% ==========
% dim = dimension of the domain of discretization
% n = total number of nodes in the domain
% ncoord = vector of nodal coordinates 
%          1d: ncoord = [x1;x2;...;xn]
%          2d: ncoord = [x1 y1;x2 y2;...;xn yn]
%          3d: ncoord = [x1 y1 z1;x2 y2 z2;...;x3 y3 z3] 
% x = sampling (evaluation) point
%          1d: x = x
%          2d: x = [x y]
%          3d: x = [x y z]
% prior_type  = name of the prior function
% gamma       = parameter that controls the basis function support-width
%             = gamma in gaussian prior and 
%             = alpha (dilation parameter) in cubic and quartic spline
%               priors
% ilambda = initial value of the lagrange multipliers
% checktest = 'yes' to perform consistensy check on phi and phider,
%             otherwise 'no'
%
% Computed variables
% ==================
% phi = vector of maxent basis functions = [phi_1;phi_2;...;phi_len]
% phider = vector containing basis functions derivatives
%          1d: phider = [phi_1,x; phi_2,x;...; phi_len,x]
%          2d: phider = [phi_1,x phi_1,y; phi_2,x phi_2,y;...; phi_len,x phi_len,y]
%          3d: phider = [phi_1,x phi_1,y phi_1,z; phi_2,x phi_2,y phi_2,z;...; phi_len,x
%                       phi_len,y phi_len,z]
% contribute = vector containing the index of the nodes that contribute to
%              phi and phider
% len = length of contribute vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function maxent

clc
close all;

% input data to start maxent computation
[dim,n,ncoord,x,prior_type,gamma,ilambda,rtol,compute,printmaxent,checktest,unstructured] = inputdata();

% characteristic nodal spacing
% OBS: THE RETURN OF THIS FUNCTION SHOULD BE PROVIDED FROM OUTSIDE TO MAXENT FUNCTION 
%      SINCE IT MAY TAKE LONG TIME IF A LARGE SET OF NODES IS USED, ESPECIALLY IN 3D. BETTER IF 
%      ANOTHER WAY TO PASS  h_node TO MAXENT FUNCTION IS EMPLOYED. FOR EXAMPLE, YOU MAY DEFINE IT 
%      AS 2 TIMES OR 3 TIMES THE LARGEST NODAL SPACING IN YOUR MESH, AND THEN PASS IT 
%      TO MAXENT FUNCTION AS AN ARGUMENT.
h_node=nodespacing(dim,n,ncoord); % NAIVE IMPLEMENTATION, BUT MUCH MORE FASTER 
                                  % THAN PREVIOUS MAXENT VERSIONS

% compute basis function and its gradient
[phi,phider,contribute,len,lambda]=computephi(dim,compute,prior_type,gamma,ilambda,rtol,x,ncoord,n,h_node,unstructured);

% print phi and phider if required
if (strcmp(printmaxent,'yes'))
  if (compute == 1)
    fprintf('\n');
    fprintf('For evaluation point:\n');
    fprintf('%f\n',x);
    fprintf('Neighbor nodes: ')
    for i=1:len
      fprintf('%d ',contribute(i));
    end
    fprintf('\n');
    fprintf('MaxEnt basis functions:\n');
    for i=1:length(phi)
      fprintf('%e\n',phi(i));
    end
    fprintf('\n');   
  elseif (compute == 2)
    if (dim == 1)
      fprintf('\n')
      fprintf('For evaluation point:\n')
      fprintf('%f\n',x)
      fprintf('Neighbor nodes: ')
      for i=1:len
        fprintf('%d ',contribute(i));
      end
      fprintf('\n');
      fprintf('MaxEnt basis functions:\n')
      for i=1:length(phi)
        fprintf('%e\n',phi(i));
      end
      fprintf('\n');
      fprintf('MaxEnt basis function gradient:\n')  
      for i=1:length(phi)
        fprintf('%e\n',phider(i,1));
      end
      fprintf('\n');
    elseif (dim == 2)
      fprintf('\n');
      fprintf('For evaluation point:\n');
      fprintf('%f\n',x);
      fprintf('Neighbor nodes: ')
      for i=1:len
        fprintf('%d ',contribute(i));
      end
      fprintf('\n');
      fprintf('MaxEnt basis functions:\n');
      for i=1:length(phi)
        fprintf('%e\n',phi(i));
      end
      fprintf('MaxEnt basis function gradient:\n');
      for i=1:length(phi)
        fprintf('%e %e\n',phider(i,1),phider(i,2));
      end
      fprintf('\n');
    elseif (dim == 3)
      fprintf('\n')
      fprintf('For evaluation point:\n')
      fprintf('%f\n',x)
      fprintf('Neighbor nodes: ')
      for i=1:len
        fprintf('%d ',contribute(i));
      end
      fprintf('\n');
      fprintf('MaxEnt basis functions:\n')
      for i=1:length(phi)
        fprintf('%e\n',phi(i));
      end
      fprintf('MaxEnt basis function gradient:\n');
      for i=1:length(phi)
        fprintf('%e %e %e\n',phider(i,1),phider(i,2),phider(i,3));
      end
      fprintf('\n');
    end
  end
end

% consistency check test if specified
if (strcmp(checktest,'yes'))
  consistencycheck(dim,x,lambda,rtol,compute,phi,phider,ncoord,contribute,len)
end




