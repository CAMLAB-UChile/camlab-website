Please read MeshFree++ documentation located in 'doc' folder.
