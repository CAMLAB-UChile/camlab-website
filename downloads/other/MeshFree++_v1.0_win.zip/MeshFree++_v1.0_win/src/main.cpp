#include <iostream>
#include <string>
#include <vector>

using namespace std;

#include "meshfree.h"

int main()
{
  /*********************************************************
  * EXAMPLE OF MAXENT COMPUTATION USING THE MESHFREE CLASS *
  *********************************************************/
  int dim = 3;                      // problem dimension, must be <= 3
  int nNodes = 8;                   // total number of nodes in the domain
  string weightName = "cubic";      // name of the weight function (prior in maxent context): "cubic", "quartic", "gaussian" 
                                    // or "constant"
  double gamma = 3.0;               // support size parameter. Typical values: 1 to 8 (gaussian), 1 to 3 (quartic or cubic) 
  double rtol = 1e-8;               // required tolerance for newton method in maxent computation
  int maxIter = 20;                 // maximum allowed number of newton's iterations
  int compute = 2;                  // =1 for basis functions, =2 for both basis functions and their derivatives
  bool printAllResults = 1;         // =1 plot a summary of the maxent computation, =0 nothing is plotted but in case 
                                    // of maxent failure
  int order = 1;                    // order of the approximation
  bool forceConsistencyCheck = 1;   // =0, don't run consistency check if not needed. =1, run consistency check even if not needed
  bool autoIncreaseSupportSize = 1; // =1, auto increase support size when there are insufficient neighbors. =0, otherwise

  Mat<double> nodeCoord(8,3);   // nodal coordinates 
  // you can also read this from a file
  nodeCoord(0,0) = 0.0; nodeCoord(0,1) = 0.0; nodeCoord(0,2) = 0.0; 
  nodeCoord(1,0) = 1.0; nodeCoord(1,1) = 0.0; nodeCoord(1,2) = 0.0;
  nodeCoord(2,0) = 1.0; nodeCoord(2,1) = 1.0; nodeCoord(2,2) = 0.0;
  nodeCoord(3,0) = 0.0; nodeCoord(3,1) = 1.0; nodeCoord(3,2) = 0.0;
  nodeCoord(4,0) = 0.0; nodeCoord(4,1) = 0.0; nodeCoord(4,2) = 1.0;
  nodeCoord(5,0) = 1.0; nodeCoord(5,1) = 0.0; nodeCoord(5,2) = 1.0;
  nodeCoord(6,0) = 1.0; nodeCoord(6,1) = 1.0; nodeCoord(6,2) = 1.0;
  nodeCoord(7,0) = 0.0; nodeCoord(7,1) = 1.0; nodeCoord(7,2) = 1.0;

  Vec<double> xSample(3);       // sample point  
  xSample(0) = 0.25; 
  xSample(1) = 0.25;
  xSample(2) = 0.25;

  Vec<double> nodeSpacing(1,0.6); // characteristic nodal spacing. can set different values for every node in the domain
                                  // by changing the length of the vector and setting up the values of the vector entries
  bool variousSamplePoints = 0;   // =0, output file will be deleted in a further computation
                                  // =1, append information to the output file (example: a loop over several evaluation points)
  
  // create a maxent object
  Maxent maxentObj(dim,nNodes,nodeCoord,xSample,nodeSpacing,weightName,gamma,
                   order,compute,autoIncreaseSupportSize,forceConsistencyCheck,
                   variousSamplePoints,printAllResults,rtol,maxIter);

  // start maxent computation
  maxentObj.computeMeshfree();

  // retrieve what you need from the meshfree class
  // in order to use it in a meshfree code
  cout << "********************************************************" << endl;
  cout << "                    MAXENT OBJECT                       " << endl;  
  cout << "THE FOLLOWING WAS OBTAINED FROM THE MESHFREE BASE CLASS:" << endl;
  cout << "********************************************************" << endl;
  cout << "BASIS FUNCTIONS:" << endl;
  Vec<double> phi = maxentObj.phi(); // type must be DOUBLE
  cout << phi << endl << endl;

  cout << "GRADIENT OF BASIS FUNCTIONS:" << endl;
  Mat<double> phiDer = maxentObj.phiDer(); // type must be DOUBLE
  cout << phiDer << endl << endl;

  cout << "INDICES OF THE CONTRIBUTING NODES (NEIGHBORS):" << endl;
  Vec<int> contribute = maxentObj.contribute(); // type must be INTEGER
  cout << contribute << endl << endl;

  cout << "LENGTH OF CONTRIBUTING VECTOR (THE NUMBER OF CONTRIBUTING NODES):" << endl;
  int length = maxentObj.length(); // type must be INTEGER
  cout << length << endl << endl;

  /*********************************************************
  *   EXAMPLE OF MLS COMPUTATION USING THE MESHFREE CLASS  *
  *********************************************************/
  dim = 3;                       // problem dimension, must be <= 3
  nNodes = 8;                    // total number of nodes in the domain
  weightName = "cubic";       // name of the weight function (prior in maxent context): "cubic", "quartic", "gaussian" or "constant"
  gamma = 3.0;                   // support size parameter. Typical values: 1 to 8 (gaussian), 1 to 3 (quartic or cubic) 
  compute = 2;                   // =1 for basis functions, =2 for both basis functions and their derivatives
  printAllResults = 1;           // =1 plot a summary of the maxent computation, =0 nothing is plotted but in case of mls 
                                 // failure only if checkMomentMatrixInv = 1
  order = 1;                     // order of the approximation
  forceConsistencyCheck = 1;     // =0, don't run consistency check if not needed. =1, run consistency check even if not needed
  autoIncreaseSupportSize = 1;   // =1, auto increase support size when there are insufficient neighbors. =0, otherwise

  // nodal coordinates
  nodeCoord(0,0) = 0.0; nodeCoord(0,1) = 0.0; nodeCoord(0,2) = 0.0; 
  nodeCoord(1,0) = 1.0; nodeCoord(1,1) = 0.0; nodeCoord(1,2) = 0.0;
  nodeCoord(2,0) = 1.0; nodeCoord(2,1) = 1.0; nodeCoord(2,2) = 0.0;
  nodeCoord(3,0) = 0.0; nodeCoord(3,1) = 1.0; nodeCoord(3,2) = 0.0;
  nodeCoord(4,0) = 0.0; nodeCoord(4,1) = 0.0; nodeCoord(4,2) = 1.0;
  nodeCoord(5,0) = 1.0; nodeCoord(5,1) = 0.0; nodeCoord(5,2) = 1.0;
  nodeCoord(6,0) = 1.0; nodeCoord(6,1) = 1.0; nodeCoord(6,2) = 1.0;
  nodeCoord(7,0) = 0.0; nodeCoord(7,1) = 1.0; nodeCoord(7,2) = 1.0;
  
  // sample point
  xSample(0) = 0.25; 
  xSample(1) = 0.25;
  xSample(2) = 0.25;
  
  // characteristic nodal spacing
  nodeSpacing(0)= 0.6; 
  
  // append to the meshfree results file
  variousSamplePoints = 1; 

  // create a mls object
  Mls mlsObj(dim,nNodes,nodeCoord,xSample,nodeSpacing,weightName,gamma,
             order,compute,autoIncreaseSupportSize,forceConsistencyCheck,
             variousSamplePoints,printAllResults);

  // start mls computation
  mlsObj.computeMeshfree();

  // retrieve what you need from the meshfree class
  // in order to use it in a meshfree code
  cout << "********************************************************" << endl;
  cout << "                      MLS OBJECT                        " << endl;  
  cout << "THE FOLLOWING WAS OBTAINED FROM THE MESHFREE BASE CLASS:" << endl;
  cout << "********************************************************" << endl;
  cout << "BASIS FUNCTIONS:" << endl;
  phi = mlsObj.phi();
  cout << phi << endl << endl;

  cout << "GRADIENT OF BASIS FUNCTIONS:" << endl;
  phiDer = mlsObj.phiDer(); 
  cout << phiDer << endl << endl;

  cout << "INDICES OF THE CONTRIBUTING NODES (NEIGHBORS):" << endl;
  contribute = mlsObj.contribute();
  cout << contribute << endl << endl;

  cout << "LENGTH OF CONTRIBUTING VECTOR (THE NUMBER OF CONTRIBUTING NODES):" << endl;
  length = mlsObj.length(); // type must be INTEGER
  cout << length << endl << endl << endl;
  //
  return 0;
}
