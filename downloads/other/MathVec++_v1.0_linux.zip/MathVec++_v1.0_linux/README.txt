Please read MathVec++ documentation located in 'doc' folder.
