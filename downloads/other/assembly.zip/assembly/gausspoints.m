% function [x,w]=gausspoints(xy)
%
% Purpose
% =======                                                                      
% Compute gauss points of quadratic order in cartesian coordinates for 3-node
% triangles
%
% Variables
% =========
% xy     : element nodal coordinates [n1x n1y; n2x n2y; n3x n3y]
%
% Return
% ======
% x      : Gauss points in cartesian coordinates [x1 y1; x2 y2; x3 y3]
% w      : Gauss weights [w1 w2 w3]
%
% References
% ==========
% [1] Zienkiewicz O.C., Taylor R.L., The Finite Element Method. Fifth
% Edition. Volume 1, The Basis. Butterworth-Heinemann, MA, USA.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function [x,w]=gausspoints(xy)

% triangular coordinates
tcoord=[2.0/3.0 1.0/6.0 1.0/6.0;...
        1.0/6.0 2.0/3.0 1.0/6.0;...
        1.0/6.0 1.0/6.0 2.0/3.0]; 

% gauss points in cartesian coordinates
x=tcoord*xy;
  
% area of the element
area=1.0/2.0*abs(xy(1,1)*(xy(3,2)-xy(2,2))+...
       xy(3,1)*(xy(2,2)-xy(1,2))+...
       xy(2,1)*(xy(1,2)-xy(3,2)));

% weights 
w=[area/3.0 area/3.0 area/3.0];



    
    
    







