%                                                                                                        
%                            MAIN FUNCTION                                     
%                                                                              
%                     Created by Alejandro A. Ortiz                            
%                www.computationalmechanics.org/~aortizb
%                          alortiz@ucdavis.edu
%                           
%          Department of Civil and Environmental Engineering                  
%	         University of California, Davis, CA 95616, U.S.A.               
%                                                                              
%                           February 7, 2010
%
%-------------------------------------------------------------------------------
%      USAGE:  [time1,time2,time3]=main(xmin,xmax,ymin,ymax,divx,divy)
%-------------------------------------------------------------------------------
% Purpose
% =======
% Compare computing time of three assembly methods for finite element matrices. 
% The stiffness matrix for the two-dimensional heat conduction problem on the 
% domain (xmin,xmax)x(ymin,ymax) is considered. A uniform mesh of divx x divy 
% triangles is used.
%
% Variables
% =========
% xmin   : x-coordinate minimum value
% xmax   : x-coordinate maximum value
% ymin   : y-coordinate minimum value
% ymax   : y-coordinate maximum value
% divx   : number of divisions along x-direction
% divy   : number of divisions along y-direction
%
% Return
% ======
% time1  : elapsed time for assembly method 1
% time2  : elapsed time for assembly method 2
% time3  : elapsed time for assembly method 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

function [time1,time2,time3]=main(xmin,xmax,ymin,ymax,divx,divy)

clc

time1=assembly1(xmin,xmax,ymin,ymax,divx,divy);
time2=assembly2(xmin,xmax,ymin,ymax,divx,divy);
time3=assembly3(xmin,xmax,ymin,ymax,divx,divy);




    
    
    







